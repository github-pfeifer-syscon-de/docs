GLglobe
=======
=========================================================================
DESCRIPTION:

This is a MacOS portage for GLglobe, with limited functions.
The included Textures (c) https://www.solarsystemscope.com/.


================================================================================
BUILD REQUIREMENTS:

Mac version: Mac OS X 10.8 or later, Xcode 8 or later

================================================================================
RUNTIME REQUIREMENTS:

Mac version: Mac OS X 10.8 or later
