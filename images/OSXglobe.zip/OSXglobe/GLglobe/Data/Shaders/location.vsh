/*
 *    File: location.vsh
 * Abstract: The vertex shader for reflection rendering.
 */

#ifdef GL_ES
precision highp float;
#endif

uniform mat4 modelViewProjectionMatrix;
uniform vec3 inColor;

// Declare inputs and outputs
// inPosition : Position attribute from the VAO/VBOs
// gl_Position : Implicitly declared in all vertex shaders.  The clip space
//               position passed to rasterizer used to build the triangles

#if __VERSION__ >= 140
in vec4  inPosition;
out vec4 varColor;
#else
attribute vec4 inPosition;
varying vec4 varColor;
#endif

void main (void)
{
    gl_Position	= modelViewProjectionMatrix * inPosition;
    varColor = vec4(inColor, 1.0);
}
