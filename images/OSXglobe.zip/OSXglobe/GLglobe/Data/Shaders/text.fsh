/*
 *    File: text.fsh
 * Abstract: The fragment shader for text rendering.
 */

#ifdef GL_ES
precision highp float;
#endif



// Declare inputs and outputs
// gl_FragColor : Implicitly declare in fragments shaders less than 1.40.
//                The output color of our fragment.
// fragColor : Output color of our fragment.  Basically the same as gl_FragColor,
//             but we must explicitly declared this in shaders version 1.40 and
//             above.

#if __VERSION__ >= 140
in vec2     varTexcoord;
out vec4    fragColor;
#else
varying vec2 varTexcoord;
#endif

uniform sampler2D textTexture;

void main (void)
{
#if __VERSION__ >= 140
    fragColor = texture(textTexture, varTexcoord);
#else
    gl_FragColor = texture2D(textTexture, varTexcoord);
#endif

}
