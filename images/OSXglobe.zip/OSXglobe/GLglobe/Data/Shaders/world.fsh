/*
 *     File: world.fsh
 */

#ifdef GL_ES
precision highp float;
#endif

// Declare inputs and outputs
// varTexcoord : TexCoord for the fragment computed by the rasterizer based on
//               the varTexcoord values output in the vertex shader.
// gl_FragColor : Implicitly declare in fragments shaders less than 1.40.
//                Output color of our fragment.
// fragColor : Output color of our fragment.  Basically the same as gl_FragColor,
//             but we must explicitly declared this in shaders version 1.40 and
//             above.

// define light
uniform vec3 lightPosition_worldspace;
uniform float twilight;

#if __VERSION__ >= 140
in vec2     varTexcoord;
in vec3     varNormal;
out vec4    fragColor;
#else
varying vec2 varTexcoord;
varying vec3 varNormal;
#endif

uniform sampler2D dayTexture;
uniform sampler2D nightTexture;

void main (void)
{
    float shade = dot(normalize(lightPosition_worldspace), (varNormal));
    float day;
    if (shade < -twilight) {
        day = 0.0;
    }
    else if (shade > twilight) {
        day = 1.0;
    } else {
        day = (shade + twilight) / (2.0 * twilight);
    }
    float night = 1.0 - day;
	#if __VERSION__ >= 140
    fragColor = (day * texture(dayTexture, varTexcoord.st, 0.0))
                + (night * texture(nightTexture, varTexcoord.st, 0.0));
	#else
    gl_FragColor = (day * texture2D(dayTexture, varTexcoord.st, 0.0))
                + (night * exture2D(nightTexture, varTexcoord.st, 0.0));
	#endif
        
}
