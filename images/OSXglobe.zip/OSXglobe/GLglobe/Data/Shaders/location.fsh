/*
 *    File: location.fsh
 * Abstract: The fragment shader for indicating locations.
 */

#ifdef GL_ES
precision highp float;
#endif



// Declare inputs and outputs
// gl_FragColor : Implicitly declare in fragments shaders less than 1.40.
//                The output color of our fragment.
// fragColor : Output color of our fragment.  Basically the same as gl_FragColor,
//             but we must explicitly declared this in shaders version 1.40 and
//             above.

#if __VERSION__ >= 140
out vec4    fragColor;
in vec4     varColor;
#else
varying vec4 varColor;
#endif



void main (void)
{
#if __VERSION__ >= 140
    fragColor = varColor;
#else
    gl_FragColor = varColor;
#endif

}
