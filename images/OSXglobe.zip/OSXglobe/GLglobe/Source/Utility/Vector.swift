//
//  Vector.swift
//  GLEssentials
//
//  Created by Roland Pfeifer on 2021-11-04
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation
import GLKit
class Vect4  {
    var x , y, z, w:Float
     init() {
        //super.init();
        self.x = 0.0
        self.y = 0.0
        self.z = 0.0
        self.w = 0.0
    }
    init(x:Float, y:Float, z:Float, w:Float) {
        self.x = x
        self.y = y
        self.z = z
        self.w = w
    }
    func add(add: Vect4) -> Vect4 {
        return Vect4(x: x + add.x,  y: y + add.y, z: z + add.z, w: w + add.w)
    }
    func subtract(sub: Vect4) -> Vect4 {
        return Vect4(x: x - sub.x,  y: y - sub.y, z: z - sub.z, w: w - sub.w)
    }
    func multiply(mul: Vect4) -> Vect4 {
        return Vect4(x: x * mul.x,  y: y * mul.y, z: z * mul.z, w: w * mul.w)
    }
    func divide(div: Vect4) -> Vect4 {
        return Vect4(x: x / div.x,  y: y / div.y, z: z / div.z, w: w / div.w)
    }
    func dotProduct(dot: Vect4) -> Float {
        return x * dot.x + y * dot.y + z * dot.z + w * dot.w
    }
    func toArray() -> [Float] {
        let arr = [x,y,z,w]
        return arr
    }
    
}

public class Vect3 {
    var x , y, z:Float
    public init() {
        //super.init();
        self.x = 0.0
        self.y = 0.0
        self.z = 0.0
    }
    public init(x:Float, y:Float, z:Float) {
        self.x = x
        self.y = y
        self.z = z
    }
    public init(vect:Vect3) {
        self.x = vect.x
        self.y = vect.y
        self.z = vect.z
    }
    public func rotate(horzRad:Float, vertRad:Float) {
        let cosVert = cos(vertRad)
        let sinVert = sin(vertRad)
        let sinHorz = sin(horzRad)
        let cosHorz = cos(horzRad)
        self.x = cosVert * sinHorz
        self.y = sinVert
        self.z = cosVert * cosHorz
    }
    public func right(horzRad:Float) {
        let Pi2 = Float.pi / 2.0
        self.x = sin(horzRad - Pi2)
        self.y = 0.0
        self.z = cos(horzRad - Pi2)
    }
    public func add(add: Vect3) -> Vect3 {
        return Vect3(x: x + add.x, y: y + add.y, z: z + add.z)
    }
    public func subtract(sub: Vect3) -> Vect3 {
        return Vect3(x: x - sub.x, y: y - sub.y, z: z - sub.z)
    }
    public func multiply(mul: Vect3) -> Vect3 {
        return Vect3(x: x * mul.x, y: y * mul.y, z: z * mul.z)
    }
    public func divide(div: Vect3) -> Vect3 {
        return Vect3(x: x / div.x, y: y / div.y, z: z / div.z)
    }
    public func dot(product: Vect3) -> Float {
        return x * product.x + y * product.y + z * product.z
    }
    public func cross(product: Vect3) -> Vect3 {
        return Vect3(x: y * product.z - z * product.y
                   ,y: z * product.x - x * product.z
                   ,z: x * product.y - y * product.x)
    }
    public func length() -> Float {
        return sqrt(x*x + y*y + z*z)
    }
    public func scale(factor: Float) {
        self.x *= factor
        self.y *= factor
        self.z *= factor
    }
    public func normalize() {
        let length = self.length()
        
        self.x = self.x/length;
        self.y = self.y/length;
        self.z = self.z/length;
    }
    public func toArray() -> [Float] {
        let arr = [x,y,z]
        return arr
    }
}
// Some helpers for GLK library functions
func GLKVector3MakeRotate(horzRad: Float, vertRad: Float) -> GLKVector3 {
    let cosVert = cos(vertRad)
    let sinVert = sin(vertRad)
    let sinHorz = sin(horzRad)
    let cosHorz = cos(horzRad)
    return GLKVector3Make(cosVert * sinHorz, sinVert, cosVert * cosHorz)
}
func GLKVector3MakeRight(horzRad: Float) -> GLKVector3 {
    let Pi2 = Float.pi / 2.0
    return GLKVector3Make(sin(horzRad - Pi2), Float(0.0), cos(horzRad - Pi2))
}

extension GLKVector3 {
    func toArray() -> [Float] {
        var arr = [Float]()
        arr.append(x)
        arr.append(y)
        arr.append(z)
        return arr
    }
    func toGL(unifomIdx: GLint) {
        glUniform3fv(unifomIdx, 1, toArray())
    }
}
