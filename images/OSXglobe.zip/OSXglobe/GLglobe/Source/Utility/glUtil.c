//
//  glUtil.c
//  GLEssentials
//
//  Created by Roland Pfeifer on 02/11/21.
//

#include "glUtil.h"
#include <inttypes.h>
#include <mach/mach_time.h>

static uint64_t clockTicksStart = 0l;

// return a monotone timebase advancing by 1 for every second elapsed
float utlFloatTime()
{
    uint64_t clockTicksSinceSystemBoot = mach_absolute_time();
    if (clockTicksStart == 0l) {
        clockTicksStart = clockTicksSinceSystemBoot;
    }
    clockTicksSinceSystemBoot = clockTicksSinceSystemBoot - clockTicksStart;
    
    static mach_timebase_info_data_t timebase;
    mach_timebase_info(&timebase);
    // Cast to double is required to make this a floating point devision,
    double clockTicksToNanosecons = (double)timebase.numer / (double)timebase.denom;
    //printf("Clock ticks since system boot: %"PRIu64" %.3f\n",
    //       clockTicksSinceSystemBoot, _characterAngle);
    
    return (float)((double)clockTicksSinceSystemBoot * clockTicksToNanosecons / 1.0e9);
}
