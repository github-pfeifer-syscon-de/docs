//
//  SunCalc.c
//
//  Copyright © 2021 https://github.com/buelowp/sunset/blob/master/src/sunset.cpp

#include <stdio.h>
#include <math.h>

#include "SunCalc.h"

double m_latitude;
double m_longitude;
double m_julianDate;
double m_tzOffset;
int m_year;
int m_month;
int m_day;

void setSunLonLat(double lon, double lat) {
    m_latitude = lat;
    m_longitude = lon;
}

float roundTo(float deg,float to) {
    while (deg < 0) {
        deg += to;
    }
    while (deg > to) {
        deg -= to;
    }
    return deg;
}

double degToRad(double deg) {
    return deg * M_PI / 180.0;
}

double radToDeg(double rad) {
    return rad * 180.0 / M_PI;
}

double calcMeanObliquityOfEcliptic(double t)
{
    double seconds = 21.448 - t*(46.8150 + t*(0.00059 - t*(0.001813)));
    double e0 = 23.0 + (26.0 + (seconds/60.0))/60.0;

    return e0;              // in degrees
}

double calcGeomMeanLongSun(double t)
{
    if (isnan(t)) {
        return NAN;
    }
    double L = 280.46646 + t * (36000.76983 + 0.0003032 * t);

    return fmod(L, 360.0);
}

double calcObliquityCorrection(double t)
{
    double e0 = calcMeanObliquityOfEcliptic(t);
    double omega = 125.04 - 1934.136 * t;
    double e = e0 + 0.00256 * cos(degToRad(omega));

    return e;               // in degrees
}

double calcEccentricityEarthOrbit(double t)
{
    double e = 0.016708634 - t * (0.000042037 + 0.0000001267 * t);
    return e;               // unitless
}

double calcGeomMeanAnomalySun(double t)
{
    double M = 357.52911 + t * (35999.05029 - 0.0001537 * t);
    return M;               // in degrees
}

double calcEquationOfTime(double t)
{
    double epsilon = calcObliquityCorrection(t);
    double l0 = calcGeomMeanLongSun(t);
    double e = calcEccentricityEarthOrbit(t);
    double m = calcGeomMeanAnomalySun(t);
    double y = tan(degToRad(epsilon)/2.0);

    y *= y;

    double sin2l0 = sin(2.0 * degToRad(l0));
    double sinm   = sin(degToRad(m));
    double cos2l0 = cos(2.0 * degToRad(l0));
    double sin4l0 = sin(4.0 * degToRad(l0));
    double sin2m  = sin(2.0 * degToRad(m));
    double Etime = y * sin2l0 - 2.0 * e * sinm + 4.0 * e * y * sinm * cos2l0 - 0.5 * y * y * sin4l0 - 1.25 * e * e * sin2m;
    return radToDeg(Etime)*4.0;	// in minutes of time
}

double calcTimeJulianCent(double jd) 
{
    double T = ( jd - 2451545.0)/36525.0;
    return T;
}


double calcHourAngleSunrise(double lat, double solarDec, double offset)
{
    double latRad = degToRad(lat);
    double sdRad  = degToRad(solarDec);
    double HA = (acos(cos(degToRad(offset))/(cos(latRad)*cos(sdRad))-tan(latRad) * tan(sdRad)));

    return HA;              // in radians
}

double calcHourAngleSunset(double lat, double solarDec, double offset)
{
    double latRad = degToRad(lat);
    double sdRad  = degToRad(solarDec);
    double HA = (acos(cos(degToRad(offset))/(cos(latRad)*cos(sdRad))-tan(latRad) * tan(sdRad)));

    return -HA;              // in radians
}

/**
 * \fn double SunSet::calcJD(int y, int m, int d) 
 * \param y Integer year as a 4 digit value
 * \param m Integer month, not 0 based
 * \param d Integer day, not 0 based
 * \return Returns the Julian date as a double for the calculations
 *
 * A well known JD calculator
 */
double calcJD(int y, int m, int d) 
{
    if (m <= 2) {
        y -= 1;
        m += 12;
    }
    double A = floor(y/100);
    double B = 2.0 - A + floor(A/4);

    double JD = floor(365.25*(y + 4716)) + floor(30.6001*(m+1)) + d + B - 1524.5;
    return JD;
}

double calcJDFromJulianCent(double t)
{
    double JD = t * 36525.0 + 2451545.0;
    return JD;
}

double calcSunEqOfCenter(double t)
{
    double m = calcGeomMeanAnomalySun(t);
    double mrad = degToRad(m);
    double sinm = sin(mrad);
    double sin2m = sin(mrad+mrad);
    double sin3m = sin(mrad+mrad+mrad);
    double C = sinm * (1.914602 - t * (0.004817 + 0.000014 * t)) + sin2m * (0.019993 - 0.000101 * t) + sin3m * 0.000289;

    return C;		// in degrees
}

double calcSunTrueLong(double t)
{
    double l0 = calcGeomMeanLongSun(t);
    double c = calcSunEqOfCenter(t);

    double O = l0 + c;
    return O;               // in degrees
}

double calcSunApparentLong(double t)
{
    double o = calcSunTrueLong(t);

    double  omega = 125.04 - 1934.136 * t;
    double  lambda = o - 0.00569 - 0.00478 * sin(degToRad(omega));
    return lambda;          // in degrees
}

double calcSunDeclination(double t)
{
    double e = calcObliquityCorrection(t);
    double lambda = calcSunApparentLong(t);

    double sint = sin(degToRad(e)) * sin(degToRad(lambda));
    double theta = radToDeg(asin(sint));
    return theta;           // in degrees
}

/**
 * \fn double SunSet::calcAbsSunrise(double offset) const
 * \param offset Double The specific angle to use when calculating sunrise
 * \return Returns the time in minutes past midnight in UTC for sunrise at your location
 *
 * This does a bunch of work to get to an accurate angle. Note that it does it 2x, once
 * to get a rough position, and then it doubles back and redoes the calculations to
 * refine the value. The first time through, it will be off by as much as 2 minutes, but
 * the second time through, it will be nearly perfect.
 *
 * Note that this is the base calculation for all sunrise calls. The others just modify
 * the offset angle to account for the different needs.
 */
double calcAbsSunrise(double offset)
{
    double t = calcTimeJulianCent(m_julianDate);
    // *** First pass to approximate sunrise
    double  eqTime = calcEquationOfTime(t);
    double  solarDec = calcSunDeclination(t);
    double  hourAngle = calcHourAngleSunrise(m_latitude, solarDec, offset);
    double  delta = m_longitude + radToDeg(hourAngle);
    double  timeDiff = 4 * delta;	// in minutes of time
    double  timeUTC = 720 - timeDiff - eqTime;	// in minutes
    double  newt = calcTimeJulianCent(calcJDFromJulianCent(t) + timeUTC/1440.0);

    eqTime = calcEquationOfTime(newt);
    solarDec = calcSunDeclination(newt);

    hourAngle = calcHourAngleSunrise(m_latitude, solarDec, offset);
    delta = m_longitude + radToDeg(hourAngle);
    timeDiff = 4 * delta;
    timeUTC = 720 - timeDiff - eqTime; // in minutes
    return timeUTC;	// return time in minutes from midnight
}

/**
 * \fn double SunSet::calcAbsSunset(double offset) const
 * \param offset Double The specific angle to use when calculating sunset
 * \return Returns the time in minutes past midnight in UTC for sunset at your location
 *
 * This does a bunch of work to get to an accurate angle. Note that it does it 2x, once
 * to get a rough position, and then it doubles back and redoes the calculations to
 * refine the value. The first time through, it will be off by as much as 2 minutes, but
 * the second time through, it will be nearly perfect.
 *
 * Note that this is the base calculation for all sunset calls. The others just modify
 * the offset angle to account for the different needs.
 */
double calcAbsSunset(double offset) 
{
    double t = calcTimeJulianCent(m_julianDate);
    // *** First pass to approximate sunset
    double  eqTime = calcEquationOfTime(t);
    double  solarDec = calcSunDeclination(t);
    double  hourAngle = calcHourAngleSunset(m_latitude, solarDec, offset);
    double  delta = m_longitude + radToDeg(hourAngle);
    double  timeDiff = 4 * delta;	// in minutes of time
    double  timeUTC = 720 - timeDiff - eqTime;	// in minutes
    double  newt = calcTimeJulianCent(calcJDFromJulianCent(t) + timeUTC/1440.0);

    eqTime = calcEquationOfTime(newt);
    solarDec = calcSunDeclination(newt);

    hourAngle = calcHourAngleSunset(m_latitude, solarDec, offset);
    delta = m_longitude + radToDeg(hourAngle);
    timeDiff = 4 * delta;
    timeUTC = 720 - timeDiff - eqTime; // in minutes

    return timeUTC;	// return time in minutes from midnight
}


/**
 * \fn double SunSet::calcCustomSunrise(double angle) const
 * \param angle The angle in degrees over the horizon at which to calculate the sunset time
 * \return Returns sunrise at angle degrees in minutes past midnight.
 *
 * This function will return the sunrise in local time for your location for any
 * angle over the horizon, where < 90 would be above the horizon, and > 90 would be at or below.
 */
double calcCustomSunrise(double angle)
{
    //printf("tz: %.3lf lat: %.3lf lon: %.3lf jd: %.0f\n", m_tzOffset, m_latitude, m_longitude, m_julianDate);
    return calcAbsSunrise(angle) + (60 * m_tzOffset);
}

/**
 * \fn double SunSet::calcCustomSunset(double angle) const
 * \param angle The angle in degrees over the horizon at which to calculate the sunset time
 * \return Returns sunset at angle degrees in minutes past midnight.
 *
 * This function will return the sunset in local time for your location for any
 * angle over the horizon, where < 90 would be above the horizon, and > 90 would be at or below.
 */
double calcCustomSunset(double angle)
{
    return calcAbsSunset(angle) + (60 * m_tzOffset);
}

/**
 * \fn double SunSet::calcSunrise() const
 * \return Returns local sunrise in minutes past midnight.
 *
 * This function will return the Official sunrise in local time for your location
 */
double calcSunrise()
{
    return calcCustomSunrise(SUNSET_OFFICIAL);
}

/**
 * \fn double SunSet::calcSunset() const
 * \return Returns local sunset in minutes past midnight.
 *
 * This function will return the Official sunset in local time for your location
 */
double calcSunset()
{
    return calcCustomSunset(SUNSET_OFFICIAL);
}

/**
 * double SunSet::setCurrentDate(int y, int m, int d)
 * \param y Integer year, must be 4 digits
 * \param m Integer month, not zero based (Jan = 1)
 * \param d Integer day of month, not zero based (month starts on day 1)
 * \return Returns the result of the Julian Date conversion if you want to save it
 *
 * Since these calculations are done based on the Julian Calendar, we must convert
 * our year month day into Julian before we use it. You get the Julian value for
 * free if you want it.
 */
double setSunCurrentDateYMD(int y, int m, int d)
{
    m_year = y;
    m_month = m;
    m_day = d;
    m_julianDate = calcJD(y, m, d);
    return m_julianDate;
}

/**
 * \fn void SunSet::setTZOffset(double tz)
 * \param tz Double timezone, may be positive or negative
 *
 * Critical to set your timezone so results are accurate for your time and date.
 * This function is critical to make sure the system works correctly. If you
 * do not set the timezone correctly, the return value will not be correct for
 * your location. Forgetting this will result in return values that may actually
 * be negative in some cases.
 */
void setSunTZOffset(double tz)
{
    if (tz >= -12 && tz <= 14)
        m_tzOffset = tz;
    else
        m_tzOffset = 0.0;
}

double getSunDeclination()
{
    double t = calcTimeJulianCent(m_julianDate);
    double  solarDec = calcSunDeclination(t);
    return solarDec;
}

