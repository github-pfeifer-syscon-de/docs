//
//  SunCalc.h
//  GLglobe
//
//  Copyright © 2021 https://github.com/buelowp/sunset/blob/master/src/sunset.cpp
//

#ifndef SunCalc_h
#define SunCalc_h
static const double SUNSET_OFFICIAL = 90.833;       /**< Standard sun angle for sunset */
static const double SUNSET_NAUTICAL = 102.0;        /**< Nautical sun angle for sunset */
static const double SUNSET_CIVIL = 96.0;            /**< Civil sun angle for sunset */
static const double SUNSET_ASTONOMICAL = 108.0;     /**< Astronomical sun angle for sunset */

void setSunTZOffset(double offsH);
double setSunCurrentDateYMD(int y, int m, int d);
void setSunLonLat(double lon, double lat);
double calcSunrise();
double calcSunset();
double getSunDeclination();

#endif /* SunCalc_h */
