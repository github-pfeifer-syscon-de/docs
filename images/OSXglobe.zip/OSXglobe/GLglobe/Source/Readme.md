GLglobe

a fancy desktop clock

build with Xcode 8.1
requires osx >= 10.10
