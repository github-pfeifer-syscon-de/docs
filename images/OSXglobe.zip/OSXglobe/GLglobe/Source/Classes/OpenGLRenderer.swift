//
//  OpenGLRenderer.swift
//  GLEssentials
//
//  Created by Roland Pfeifer on 06/11/21.
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation
import GLKit
import GLutil
import CoreVideo



@objc public class OpenGLRenderer : NSObject {
    let USE_VERTEX_BUFFER_OBJECTS : Bool = true
    let RENDER_REFLECTION : Bool = true

    var _defaultFBOName = GLuint()
//#if RENDER_REFLECTION
    var _quadModel : Model?
    var _reflectTexName = GLuint()
    var _reflectFBOName = GLuint()
    var _reflectWidth = GLuint()
    var _reflectHeight = GLuint()
    //var _reflectPrgName = GLuint()
    var _reflectProgram : ReflectShader?
    var  _reflectTextureName = GLuint()

//#endif // RENDER_REFLECTION
    //var _mainPrgName = GLuint()
    var _mainProgram: MainShader?
    var _locationProgram: LocationShader?
    var _dayTexName = GLuint()
    var _nightTexName = GLuint()
    var _mainModel: Model?
    var _timeText: Text?
    var _infoText: Text?
    var _locationModels = [LocationModel]()
    var _viewWidth = GLuint()
    var _viewHeight = GLuint()
    var _zNear = GLfloat()
    var _zFar = GLfloat()
    var _useVBOs = Bool()
    
    var _verticalAngleRad = Float()
    var _horizontalAngleRad = Float()
    var _viewDist = Float()
    var _horizontalAngleOffset = Float()

    var clockTicksStart = UInt64()
    var _showLocation = Bool()
    var mousePos = NSPoint()


    @objc public init(defaultFBO defaultFBOName:GLuint) {
        super.init()
        
        //let rendererPtr = glGetString(GLenum(GL_RENDERER))
        //let rendererString = String(cString: rendererPtr!)
        //let versionPtr = glGetString(GLenum(GL_VERSION))
        //let versionString = String(cString: versionPtr!)
        //NSLog("\(rendererString)")
        //NSLog("\(versionString)")
        
        ////////////////////////////////////////////////////
        // Build all of our and setup initial state here  //
        // Don't wait until our real time run loop begins //
        ////////////////////////////////////////////////////
        
        _defaultFBOName = defaultFBOName
        
        _viewWidth = 100
        _viewHeight = 100

        _verticalAngleRad = 0.0
        _horizontalAngleRad = 0.0
        _viewDist = 450.0
        _horizontalAngleOffset = 0.0

        _useVBOs = USE_VERTEX_BUFFER_OBJECTS
        
        
        //////////////////////////////
        // Load our character model //
        //////////////////////////////
        let r: Double = 100.0
        //filePathName = [[NSBundle mainBundle] pathForResource:@"demon" ofType:@"model"];
        //_mainModel = mdlLoadModel([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
        _mainModel = SphereModel(useVBOs:_useVBOs, radius: r, sectors: 32)
        
        // Build Vertex Buffer Objects (VBOs) and Vertex Array Object (VAOs) with our model data
        //_mainModel?.buildVAO()
        getGLError("loadVAO main")

        // Cache the number of element and primType to use later in our glDrawElements calls
        //_characterNumElements = _mainModel!.numElements
        //_characterPrimType = (_mainModel?.primType)!
        //_characterElementType = (_mainModel?.elementType)!
        
        ////////////////////////////////////
        // Load textures for our world     //
        ////////////////////////////////////
        
        var filePathName = Bundle.main.path(forResource: "2k_earth_daymap", ofType:"jpeg")
        let dayImage = Image(filepathString: filePathName!, flipVertical:true)
        
        // Build a texture object with our image data
        _dayTexName = dayImage.buildTexture()
        getGLError("day texture")

        filePathName = Bundle.main.path(forResource: "2k_earth_nightmap", ofType:"jpeg")
        let nightImage = Image(filepathString: filePathName!, flipVertical:true)
        
        // Build a texture object with our image data
        _nightTexName = nightImage.buildTexture()
        getGLError("night texture")
        
        ////////////////////////////////////////////////////
        // Load and Setup shaders for character rendering //
        ////////////////////////////////////////////////////
        
        // Build Program
        _mainProgram = MainShader(model: _mainModel!)
        getGLError("setup main shader")

        if RENDER_REFLECTION {
            
            _reflectWidth = 512;
            _reflectHeight = 512;
            
            ////////////////////////////////////////////////
            // Load a model for a quad for the reflection //
            ////////////////////////////////////////////////
            
            _quadModel = QuadModel(useVBOs:_useVBOs)
            // Build Vertex Buffer Objects (VBOs) and Vertex Array Object (VAOs) with our model data
            //_quadModel?.buildVAO()
            getGLError("loadVAO reflect")
            
            /////////////////////////////////////////////////////
            // Create texture and FBO for reflection rendering //
            /////////////////////////////////////////////////////
            
            _reflectFBOName = buildFBO(width:_reflectWidth, andHeight:_reflectHeight)
            if (_reflectFBOName == 0) {
                NSLog("No framebuffer for reflection created!")
            }
            // Get the texture we created in buildReflectFBO by binding the
            // reflection FBO and getting the buffer attached to color 0
            glBindFramebuffer(GLenum(GL_FRAMEBUFFER), _reflectFBOName)
            
            var iReflectTexName = GLint()
            
            glGetFramebufferAttachmentParameteriv(GLenum(GL_FRAMEBUFFER), GLenum(GL_COLOR_ATTACHMENT0), GLenum(GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME), &iReflectTexName)
            
            _reflectTexName = GLuint(iReflectTexName)
            
            /////////////////////////////////////////////////////
            // Load and setup shaders for reflection rendering //
            /////////////////////////////////////////////////////
            
            // Build Program
            _reflectProgram = ReflectShader(model: _quadModel!)
            
            getGLError("setup reflect")
        } // RENDER_REFLECTION
        
        ////////////////////////////////////////////////
        // Set up OpenGL state that will never change //
        ////////////////////////////////////////////////
        
        // Depth test will always be enabled
        glEnable(GLenum(GL_DEPTH_TEST))
        
        // We will always cull back faces for better performance
        glEnable(GLenum(GL_CULL_FACE))
        
        // Always use this clear color
        glClearColor(0.1, 0.1, 0.1, 1.0)
        
        // Draw our scene once without presenting the rendered image.
        //   This is done in order to pre-warm OpenGL
        // We don't need to present the buffer since we don't actually want the
        //   user to see this, we're only drawing as a pre-warm stage
        let ptr = UnsafePointer<CVTimeStamp>(bitPattern:0)
        render(ptr)
        
        // Reset the _characterAngle which is incremented in render
        //_characterAngle = 0;
        
        // Check for errors to make sure all of our setup went ok
        getGLError("after setup")
        for i in 0..<24 {
            let tzs = Tz.read(lonMin: Float(i-12) * 15.0, lonMax: Float(i-11) * 15.0)   // offset by 12 to range from -180..180
            let locationModel = LocationModel(useVBOs:_useVBOs, tzs: tzs, radius: GLfloat(r + 0.1))
            //locationModel.buildVAO()
            getGLError("loadVAO location")
            _locationModels.append(locationModel)
            if _locationProgram == nil {
                _locationProgram = LocationShader(model: locationModel)
                getGLError("setup location")
             }
        }

    }

    deinit {
        // Cleanup all OpenGL objects and
        glDeleteTextures(1, &_dayTexName)
        glDeleteTextures(1, &_nightTexName)
        
        //if _mainModel != nil {
        //    _mainModel!.destroyVAO()
        //    getGLError("Delete main VAO")
        _mainModel = nil
        //}
        //if _mainProgram != nil {
        //    glDeleteProgram(_mainProgram!.prgName)
        //}
        _mainProgram = nil
        //if _textModel != nil {
        //    _textModel!.destroyVAO()
        //    getGLError("Delete text VAO")
        //_textModel = nil
        //}
        //if _textProgram != nil {
        //    glDeleteProgram(_textProgram!.prgName)
        //}
        //_textProgram = nil
        //for locationModel in _locationModels {
        //    locationModel.destroyVAO()
        //}
        //getGLError("Delete location VAO")
        _locationModels.removeAll()
        //if _infoModel != nil {
        //    _infoModel!.destroyVAO()
        //    getGLError("Delete info VAO")
        //_infoModel = nil
        //}
        //if _locationProgram != nil {
        //    glDeleteProgram(_locationProgram!.prgName)
        //}
        _locationProgram = nil
        _timeText = nil
        _infoText = nil
        Text._textProgram = nil

        if RENDER_REFLECTION {
            destroyFBO(fboName:&_reflectFBOName)
            //if _quadModel != nil {
            //    _quadModel!.destroyVAO()
            //    getGLError("Delete reflect VAO")
            _quadModel = nil
            //}
            //if (_reflectProgram != nil) {
            //    glDeleteProgram(_reflectProgram!.prgName)
            //}
            _reflectProgram = nil
        } // RENDER_REFLECTION
    }
    
    @objc public func resize(width : GLuint, AndHeight height : GLuint) {
        glViewport(0, 0, GLsizei(width), GLsizei(height))
    
        _viewWidth = width
        _viewHeight = height
    }

    @objc public func add(zoffset: Float) {
        _viewDist += zoffset
    }

    @objc public func add(hoffset: Float) {
        _horizontalAngleOffset += hoffset
    }

    @objc public func set(inside: Int32) {
        _showLocation = inside != 0
    }

    @objc public func setMouse(pos: NSPoint) {
        self.mousePos = pos
    }

    @objc public func resetRotation() {
        _horizontalAngleOffset = 0.0
    }

    // some time useful for animation
    func utlFloatTime() -> Float {
        var clockTicksSinceSystemBoot : UInt64 = mach_absolute_time();
        if (clockTicksStart == 0) {
            clockTicksStart = clockTicksSinceSystemBoot
        }
        clockTicksSinceSystemBoot = clockTicksSinceSystemBoot - clockTicksStart
        
        var timebase = mach_timebase_info()
        mach_timebase_info(&timebase)
        // Cast to double is required to make this a floating point devision,
        let clockTicksToNanosecons = Double(timebase.numer) / Double(timebase.denom)
        //printf("Clock ticks since system boot: %"PRIu64" %.3f\n",
        //       clockTicksSinceSystemBoot, _characterAngle);
        
        return Float(Double(clockTicksSinceSystemBoot) * clockTicksToNanosecons / 1.0e9)
    }
    
    func calcuateEarthLight() -> GLKVector3   {
        var light : GLKVector3 = GLKVector3Make(0.0, 0.0, 1.0)
        var utcCalendar = Calendar(identifier: .gregorian)
        let date = Date()
        if let utcTimeZone = NSTimeZone(abbreviation: "UTC") {
            utcCalendar.timeZone = utcTimeZone as TimeZone
            var yearStart = utcCalendar.nextDate(after: date, matching: DateComponents(day: 1), matchingPolicy: .previousTimePreservingSmallerComponents, direction: .backward)
            yearStart = utcCalendar.nextDate(after: yearStart!, matching:  DateComponents(month: 1), matchingPolicy: .previousTimePreservingSmallerComponents, direction: .backward)
            let utcDateComponents = utcCalendar.dateComponents([.day,.month,.year,.hour,.minute,.second,.weekOfYear,.weekday], from: date as Date)
            let yearStartComponents = utcCalendar.dateComponents([.day,.month,.year,.hour,.minute,.second,.weekOfYear,.weekday], from: yearStart! as Date)
           
            // Create string of form "yyyy-mm-dd hh:mm:ss"
            //let utcDateTimeString = String(format: "%04u-%02u-%02u %02u:%02u:%02u", (utcDateComponents.year!), (utcDateComponents.month!), (utcDateComponents.day!), (utcDateComponents.hour!), (utcDateComponents.minute!), (utcDateComponents.second!))
           //let dayOfYear = ((utcDateComponents.weekOfYear!)-yearStartComponents.weekOfYear!) * 7 + (utcDateComponents.weekday! - yearStartComponents.weekday!) + 1
            //NSLog("time \(utcDateTimeString) week \(utcDateComponents.weekOfYear) weekday \(utcDateComponents.weekday) day of year \(dayOfYear) first week of year \(yearStartComponents.weekOfYear) first weekday \(yearStartComponents.weekday)")


            let t = (Float(utcDateComponents.hour!) * 60.0 + Float(utcDateComponents.minute!)) / (24.0 * 60.0)
            //let d = Float(dayOfYear)   // approximate season
            //std::cout <<  "s: " << s << " t: " << t << std::endl;
            let r : Float =  -t * 2.0 * Float.pi;
            // https://en.wikipedia.org/wiki/Position_of_the_Sun
            //let m_earth_declination_deg : Float = -23.44 * cos((2.0 * Float.pi) / 365.0 * (d + t + 9.0))
            setSunCurrentDateYMD(Int32(utcDateComponents.year!), Int32(utcDateComponents.month!), Int32(utcDateComponents.day!))
            // use more consistent calculation
            let m_earth_declination_deg = Float(getSunDeclination())
            //std::cout << "d: " << d << " incl: " << incl << std::endl;
            let x : Float = sin(r)
            let y : Float = tan(GLKMathDegreesToRadians(m_earth_declination_deg))
            let z : Float = cos(r)
            light = GLKVector3Make(x, y, z)
        }
        else {
            NSLog("No UTC timezone?")
        }
        return  GLKVector3Normalize(light)
    }

    func hms(_ min: Double) -> String {
        //NSLog("min \(min)")
        let m = Int(min) % 60
        let mr = Int(min - Double(m))
        //NSLog("mr \(mr)")
        let h = mr / 60
        //NSLog("h \(h)")
        return String(format: "%02d:%02d", h, m)
    }

    @objc public func render(_ outputTime: UnsafePointer<CVTimeStamp>?) {
      
        // use video for syncing with display
        //var _viewAngleDeg : GLfloat = utlFloatTime() * 30.0
        //if outputTime != nil {
        //    _viewAngleDeg = Float((outputTime?.pointee.videoTime)!) / Float((outputTime?.pointee.videoTimeScale)!)  * 30.0
            //
        //}
        _horizontalAngleRad = GLKMathDegreesToRadians(Float(Preferences.longitude) + 180.0 + _horizontalAngleOffset)    // +180 as we want to start from greenwich
        _verticalAngleRad = GLKMathDegreesToRadians(Float(Preferences.latitude))
        let _zNear : Float = 5.0
        let _zFar : Float = 1000.0
        
        let light = calcuateEarthLight() // 0,0,1.0 europe at night
        // Calculate the projection matrix
        let projection = GLKMatrix4MakePerspective(GLKMathDegreesToRadians(30.0), Float(_viewWidth) / Float(_viewHeight), _zNear, _zFar)
        // Calculate the modelview matrix to render our character
        //  at the proper position and rotation
        let direction = GLKVector3MakeRotate(horzRad: _horizontalAngleRad, vertRad: _verticalAngleRad)
        let center = GLKVector3()
        let right = GLKVector3MakeRight(horzRad: _horizontalAngleRad)
        let up = GLKVector3CrossProduct(right, direction)
        var eye = direction
        eye = GLKVector3MultiplyScalar(eye, _viewDist)      // view distance
        let modelView = GLKMatrix4MakeLookAtVec(eye, center, up)
        //mtxDebug(modelView);


        showEarth(light: light, projection: projection, modelView: modelView)

        if RENDER_REFLECTION {
            showReflection(projection: projection)
         } // RENDER_REFLECTION

        //glDisable(GLenum(GL_DEPTH_TEST))
        // Required to render with alpha
        glEnable(GLenum(GL_BLEND))  // required to draw with alpha
        glBlendFunc(GLenum(GL_SRC_ALPHA), GLenum(GL_ONE_MINUS_SRC_ALPHA))

        if _showLocation {
            showLocation(projection: projection, modelView: modelView)
        }
        showText(projection: projection)
     }

    func showEarth(light: GLKVector3, projection: GLKMatrix4, modelView: GLKMatrix4) {
        // if the program wasnt loaded we cant do much here...
        if _mainProgram == nil {
            NSLog("The main program was not loaded")
        }
        else {
            // Bind textures (shoud work for both renderings of earth
            glActiveTexture(_mainProgram!._unitDay)
            glBindTexture(GLenum(GL_TEXTURE_2D), _dayTexName)
            glActiveTexture(_mainProgram!._unitNight)
            glBindTexture(GLenum(GL_TEXTURE_2D), _nightTexName)


            if RENDER_REFLECTION {
                // Bind our refletion FBO and render our scene
                glBindFramebuffer(GLenum(GL_FRAMEBUFFER), _reflectFBOName)

                glClear(GLbitfield(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT))
                glViewport(0, 0, GLsizei(_reflectWidth), GLsizei(_reflectHeight))

                // Use the program that we previously created
                glUseProgram(_mainProgram!.prgName)
                // Set up the modelview and projection matricies
                let direction = GLKVector3MakeRotate(horzRad: _horizontalAngleRad, vertRad: _verticalAngleRad  - (Float.pi / 2.0))
                let right = GLKVector3MakeRight(horzRad: _horizontalAngleRad)
                let center = GLKVector3()
                let up = GLKVector3CrossProduct(right, direction)
                var eye = direction
                eye = GLKVector3MultiplyScalar(eye, 300.0)      // view distance 400 best view but still only partly
                let refModelView = GLKMatrix4MakeLookAtVec(eye, center, up)
                // Invert Y so that everything is rendered up-side-down
                // as it should with a reflection
                //modelView = GLKMatrix4Scale(modelView, 1.0, -1.0, 1.0)

                let refProjection = GLKMatrix4MakePerspective(GLKMathDegreesToRadians(90.0), Float(_reflectWidth) / Float(_reflectHeight), _zNear, _zFar)  // 95.0
                let mvp = GLKMatrix4Multiply(refProjection, refModelView)

                // Set the modelview projection matrix that we calculated above
                // in our vertex shader
                mvp.toGL(unifomIdx: _mainProgram!._mvpUniformIdx)
                light.toGL(unifomIdx: _mainProgram!._lightUniformIdx)
                let twilight = Preferences.twilight
                glUniform1f(_mainProgram!._twilightUniformIdx, Float(twilight) / 1000.0)

                // Cull front faces now that everything is flipped
                // with our inverted reflection transformation matrix
                glCullFace(GLenum(GL_BACK))     // with our look at, no need to tweak this

                // Draw our object
                _mainModel?.draw()

                // Bind our default FBO to render to the screen
                glBindFramebuffer(GLenum(GL_FRAMEBUFFER), _defaultFBOName)

                glViewport(0, 0, GLsizei(_viewWidth), GLsizei(_viewHeight))
            } // RENDER_REFLECTION

            glClear(GLbitfield(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT))


            // Use the program for rendering our character
            glUseProgram(_mainProgram!.prgName)

            // Multiply the modelview and projection matrix and set it in the shader
            let mvp = GLKMatrix4Multiply(projection, modelView);

            // Cull back faces now that we no longer render
            // with an inverted matrix
            glCullFace(GLenum(GL_BACK))

            // Draw our character
            // Have our shader use the modelview projection matrix
            // that we calculated above
            mvp.toGL(unifomIdx: _mainProgram!._mvpUniformIdx)
            light.toGL(unifomIdx: _mainProgram!._lightUniformIdx)
            glUniform1f(_mainProgram!._twilightUniformIdx, Float(Preferences.twilight) / 1000.0)
            
            _mainModel?.draw()
        }

    }

    func showReflection(projection: GLKMatrix4) {
        if _reflectProgram == nil {
            NSLog("The refelect program was not loaded")
        }
        else {
            // Use our shader for reflections
            glUseProgram(_reflectProgram!.prgName);

            let refModelView = GLKMatrix4MakeTranslation( 0.0, -100.0, -600.0) // 0.0f, -50.0f, -250.0f

            // Multiply the modelview and projection matrix and set it in the shader
            let refMvp = GLKMatrix4Multiply(projection, refModelView)

            // Set the modelview matrix that we calculated above
            // in our vertex shader
            refModelView.toGL(unifomIdx: _reflectProgram!._reflectModelViewUniformIdx)

            // Set the projection matrix that we calculated above
            // in our vertex shader
            refMvp.toGL(unifomIdx: _reflectProgram!._reflectProjectionUniformIdx)
            let normalMatrix = GLKMatrix4GetMatrix3(refModelView)

            // Calculate the normal matrix so that we can
            // generate texture coordinates in our fragment shader

            // The normal matrix needs to be the inverse transpose of the
            //   top left 3x3 portion of the modelview matrix
            // We don't need to calculate the inverse transpose matrix
            //   here because this will always be an orthonormal matrix
            //   thus the the inverse tranpose is the same thing

            // Set the normal matrix for our shader to use
            normalMatrix.toGL(unifomIdx: _reflectProgram!._reflectNormalMatrixUniformIdx)

            // Bind the texture we rendered-to above (i.e. the reflection texture)
            glActiveTexture(GLenum(GL_TEXTURE0))
            glBindTexture(GLenum(GL_TEXTURE_2D), _reflectTexName)

            #if !TARGET_IOS
                // Generate mipmaps from the rendered-to base level
                //   Mipmaps reduce shimmering pixels due to better filtering
                // This call is not accelarated on iOS so do not use mipmaps here
                glGenerateMipmap(GLenum(GL_TEXTURE_2D))
            #endif

            // Draw our refection plane
            _quadModel?.draw()
        }
    }

    func showText(projection: GLKMatrix4) {
        let calendar = Calendar(identifier: .gregorian)
        let date = Date()
        let dateComponents = calendar.dateComponents([.day,.month,.year,.hour,.minute,.second,.weekOfYear,.weekday], from: date )

        setSunCurrentDateYMD(Int32(dateComponents.year!), Int32(dateComponents.month!), Int32(dateComponents.day!))
        let timeZone = NSTimeZone.local
        let tzOffs = Double(timeZone.secondsFromGMT(for:date)) / 3600.0
        setSunTZOffset(tzOffs)
        let lat = Preferences.latitude
        let lon = Preferences.longitude
        setSunLonLat(Double(lon), Double(lat))
        let sunrise = hms(calcSunrise())
        let sunset = hms(calcSunset())
        
        //let riseDate = toLocal(sunrise)

        //NSLog(" rise \(sunrise) set \(sunset)")
        //let m_earth_declination_deg : Float = -23.44 * cos((2.0 * Float.pi) / 365.0 * (d + t + 9.0))
        // use more consistent calculation
        let m_earth_declination_deg = Float(getSunDeclination())

        // Create string of form "yyyy-mm-dd hh:mm:ss"
        // %rise set %set δ %dec
        var dateFormat = Preferences.dateFormat
        dateFormat = dateFormat.replacingOccurrences(of: "%rise", with: sunrise)
        dateFormat = dateFormat.replacingOccurrences(of: "%set", with: sunset)
        dateFormat = dateFormat.replacingOccurrences(of: "%dec", with: String(format: "%.2f", m_earth_declination_deg))
        let dateTimeString = GLglobeGLView.makeDate(dateFormat)
        // String(format: "%04u-%02u-%02u %02u:%02u\nrise %@ set %@ δ %.2f°", (dateComponents.year!), (dateComponents.month!), (dateComponents.day!), (dateComponents.hour!), (dateComponents.minute!), sunrise, sunset, m_earth_declination_deg)

        Text.create(text: &_timeText, txt: dateTimeString! as String)
        // text
        let modelView = GLKMatrix4MakeTranslation(-50.0, -50.0, -210.0)
        let mvp = GLKMatrix4Multiply(projection, modelView)
        //let projModelView = GLKMatrix4MakeTranslation( 100.0, 100.0, 0.0)
        mvp.toGL(unifomIdx: Text._textProgram!._mvpUniformIdx)
        _timeText?.draw()
        //glDeleteTextures(1, &timeTexName)
    }

    func showLocation(projection: GLKMatrix4, modelView: GLKMatrix4) {
        if _locationProgram == nil {
            NSLog("The location program was not loaded")
        }
        else {
            glPointSize(GLfloat(1.5))
            let mvp = GLKMatrix4Multiply(projection, modelView)
            glUseProgram(_locationProgram!.prgName)
            mvp.toGL(unifomIdx: (_locationProgram?._mvpUniformIdx)!)

            let colorDay = Preferences.locationDay
            let colorNight = Preferences.locationNight
            var utcCalendar = Calendar(identifier: .gregorian)
            let date = Date()
            var utcDateComponents: DateComponents?
            if let utcTimeZone = NSTimeZone(abbreviation: "UTC") {
                utcCalendar.timeZone = utcTimeZone as TimeZone
                utcDateComponents = utcCalendar.dateComponents([.hour,.minute,.second], from: date)
            }
            let utcHour = (utcDateComponents?.hour)!
            var h = utcHour > 12 ? 24 - utcHour : utcHour
            //NSLog("showLocation \(mousePos.x) \(mousePos.y) \(_viewWidth) \(_viewHeight) \(clipX) \(clipY)")
            // check if mouse has moved since last check ?
            var tz: Tz?
            var dist = Float(-1.0)   // searching in clip space
            var distNearest = Float(-1.0)
            var distFarest = Float(1.0)
            for locationModel in _locationModels {
                let diff = Float(12 - abs(h)) / 12.0
                let color = GLKVector3Make(Float(colorDay.redComponent) * diff + Float(colorNight.redComponent) * (1.0 - diff), Float(colorDay.greenComponent) * diff + Float(colorNight.greenComponent) * (1.0 - diff), Float(colorDay.blueComponent) * diff + Float(colorNight.blueComponent) * (1.0 - diff))
                //NSLog("hour \(utcHour) h \(h) diff \(diff) tzs \(locationModel.tzs.count)")
                color.toGL(unifomIdx: (_locationProgram?._colorUnifomIdx)!)
                locationModel.draw()
                h = h - 1
                let tzProx = locationModel.proximity(mouse: mousePos, mvp: mvp, viewWidth: _viewWidth, viewHeight: _viewHeight, dist: &dist, distNearest: &distNearest, distFarest: &distFarest)
                if tzProx != nil {
                    tz = tzProx
                }
            }
            let distMid = (distFarest - distNearest) / 2.0 + distNearest // the sphere is divide in a front and back requires no normal transform
            //NSLog("farest \(distFarest) near \(distNearest) mid \(distMid) dist \(dist)")
            if tz != nil && dist < distMid {    // exclude backside match
                //NSLog("Found tz \(tz?.name)")
                var calendar = Calendar(identifier: .gregorian)
                let date = Date()
                if let timeZone = NSTimeZone(name: (tz?.name)!) {
                    calendar.timeZone = timeZone as TimeZone
                    let dateComponents = calendar.dateComponents([.day,.month,.year,.hour,.minute,.second], from: date as Date)
                    let info = String(format: "%@ %02d:%02d", (tz?.name)!, dateComponents.hour!, dateComponents.minute!)
                    //if _infoModel != nil {
                    //    _infoModel!.destroyVAO()
                    //    _infoModel = nil
                    //}
                    // text
                    Text.create(text: &_infoText, txt: info, size: 12.0)
                    //let xyz:(x: Float,y: Float,z: Float) = LocationModel.toXYZ(lat: tz!.lat!, lon: tz!.lon!)
                    //let infoModelView = GLKMatrix4MakeTranslation(Float(xyz.x * (105.0)), Float(xyz.y * (105.0)), Float(xyz.z * (105.0)))
                    let center = GLKVector3()
                    let direction = GLKVector3Make(0.0, 0.0, -1.0)   // default orientation
                    let right = GLKVector3Make(1.0, 0.0, 0.0)
                    let up = GLKVector3CrossProduct(right, direction)
                    let infoEye = GLKVector3Make(0.0, 0.0, 200.0)
                    var infoModelView = GLKMatrix4MakeLookAtVec(infoEye, center, up)
                    let infoMvp = GLKMatrix4Multiply(projection, infoModelView)

                    infoMvp.toGL(unifomIdx: Text._textProgram!._mvpUniformIdx)
                    _infoText?.draw()
                    //glDeleteTextures(1, &infoTexName)
                }
                else {
                    NSLog("Found no timezone \(tz?.name)")
                }
            }

        }
    }

    func deleteFBOAttachment(attachment:GLenum) {
        var param = GLint()
        var objName = GLuint()

        glGetFramebufferAttachmentParameteriv(GLenum(GL_FRAMEBUFFER), attachment, GLenum(GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE), &param);
        
        if(GL_RENDERBUFFER == param)  {
            glGetFramebufferAttachmentParameteriv(GLenum(GL_FRAMEBUFFER), attachment,
                                                  GLenum(GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME),
                                                  &param);
            
            objName = GLuint(param) // converted right ?
            glDeleteRenderbuffers(1, &objName);
        }
        else if(GL_TEXTURE == param) {
            glGetFramebufferAttachmentParameteriv(GLenum(GL_FRAMEBUFFER), attachment,
                                                  GLenum(GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME),
                                                  &param);
            
            objName = GLuint(param) // converted right ?
            glDeleteTextures(1, &objName)
        }
    }
    
    func destroyFBO(fboName:inout GLuint)  {
        if(0 == fboName) {
            return;
        }
        
        glBindFramebuffer(GLenum(GL_FRAMEBUFFER), fboName);
        
        var maxColorAttachments : GLint = 1
        
        // OpenGL ES 2.0 has only 1 attachment.
        // There are many possible attachments on OpenGL  os OSX so we query
        // how many below so that we can delete all attached renderbuffers
        #if !TARGET_IOS
            glGetIntegerv(GLenum(GL_MAX_COLOR_ATTACHMENTS), &maxColorAttachments);
        #endif
        
        // For every color buffer attached
        for colorAttachment in 0..<maxColorAttachments {
            // Delete the attachment
            let colorAttachment : GLint = GL_COLOR_ATTACHMENT0+colorAttachment
            deleteFBOAttachment(attachment: GLenum(colorAttachment))
        }
        
        // Delete any depth or stencil buffer attached
        deleteFBOAttachment(attachment: GLenum(GL_DEPTH_ATTACHMENT))
        
        deleteFBOAttachment(attachment: GLenum(GL_STENCIL_ATTACHMENT))
        
        glDeleteFramebuffers(1,&fboName)
    }
    
    
    func buildFBO(width: GLuint, andHeight height:GLuint) -> GLuint {
        var fboName = GLuint()
        
        var colorTexture = GLuint()
        
        // Create a texture object to apply to model
        glGenTextures(1, &colorTexture)
        glBindTexture(GLenum(GL_TEXTURE_2D), colorTexture)
        
        // Set up filter and wrap modes for this texture object
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_S), GL_CLAMP_TO_EDGE)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_T), GL_CLAMP_TO_EDGE)
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MAG_FILTER), GL_LINEAR)
        
        // Mipmap generation is not accelerated on iOS so we cannot enable trilinear filtering
        #if TARGET_IOS
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        #else
            glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MIN_FILTER), GL_LINEAR_MIPMAP_LINEAR)
        #endif
        
        // Allocate a texture image with which we can render to
        // Pass NULL for the data parameter since we don't need to load image data.
        //     We will be generating the image by rendering to this texture
        glTexImage2D(GLenum(GL_TEXTURE_2D), 0, GL_RGBA, GLsizei(width), GLsizei(height), 0, GLenum(GL_RGBA), GLenum(GL_UNSIGNED_BYTE), nil)
        
        var depthRenderbuffer = GLuint()
        glGenRenderbuffers(1, &depthRenderbuffer);
        glBindRenderbuffer(GLenum(GL_RENDERBUFFER), depthRenderbuffer);
        glRenderbufferStorage(GLenum(GL_RENDERBUFFER), GLenum(GL_DEPTH_COMPONENT16), GLsizei(width), GLsizei(height))
        
        glGenFramebuffers(1, &fboName);
        glBindFramebuffer(GLenum(GL_FRAMEBUFFER), fboName)
        glFramebufferTexture2D(GLenum(GL_FRAMEBUFFER), GLenum(GL_COLOR_ATTACHMENT0), GLenum(GL_TEXTURE_2D), colorTexture, 0)
        glFramebufferRenderbuffer(GLenum(GL_FRAMEBUFFER), GLenum(GL_DEPTH_ATTACHMENT), GLenum(GL_RENDERBUFFER), depthRenderbuffer)
        
        let fbStat = glCheckFramebufferStatus(GLenum(GL_FRAMEBUFFER))
        if(fbStat != UInt32(GL_FRAMEBUFFER_COMPLETE))  {
            NSLog("failed to make complete framebuffer object \(fbStat)");
            destroyFBO(fboName: &fboName)
            return 0
        }
        
        getGLError("FramebufferCreation")
        
        return fboName
    }
  
    
    func getGLError(_ message: @autoclosure () -> String, _  file: String = #file, line: Int = #line, function: String = #function) {
        var err : GLenum = glGetError()
        while (err != GLenum(GL_NO_ERROR)) {
            let glMsg = GetGLErrorString(err)?.debugDescription
            let usrMsg : String = message()
            NSLog("GLError \(err) set in File: \(file) Function: \(function) Line:\(line) Message: \(usrMsg) GL: \(glMsg)")
            err = glGetError()
        }
    }
    /* using c function as it has the right defines ...
    func getGLErrorString(error: GLenum) -> String {
        let ierr = GLint(error)
        var str : String
        switch(ierr) {
        case GL_NO_ERROR:
            str = "GL_NO_ERROR"
            break
        case GL_INVALID_ENUM:
            str = "GL_INVALID_ENUM"
            break
        case GL_INVALID_VALUE:
            str = "GL_INVALID_VALUE"
            break
        case GL_INVALID_OPERATION:
            str = "GL_INVALID_OPERATION"
            break
        //#if defined __gl_h_ || defined __gl3_h_
        case GL_OUT_OF_MEMORY:
            str = "GL_OUT_OF_MEMORY"
            break
        case GL_INVALID_FRAMEBUFFER_OPERATION:
            str = "GL_INVALID_FRAMEBUFFER_OPERATION"
            break
            //#endif
        //#if defined __gl_h_
        //case GL_STACK_OVERFLOW:
        //    str = "GL_STACK_OVERFLOW"
        //    break
        //case GL_STACK_UNDERFLOW:
        //    str = "GL_STACK_UNDERFLOW"
        //    break
        //case GL_TABLE_TOO_LARGE:
        //    str = "GL_TABLE_TOO_LARGE"
        //    break
        //#endif
        default:
            str = "(ERROR: Unknown Error Enum \(ierr))"
            break;
        }
        return str;
    }
     */
}
