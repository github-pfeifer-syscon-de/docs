//
//  SunCalc.swift
//  GLglobe
//
//  Created by Roland Pfeifer on 11/11/21.
//  see https://edwilliams.org/sunrise_sunset_algorithm.htm
//

import Foundation
import GLKit

public class SunCalc {
    func sunRiseSet() -> (Float) {
        let calendar = Calendar(identifier: .gregorian)
        let date = Date()
        let dateComponents = calendar.dateComponents([.day,.month,.year,.hour,.minute,.second,.weekOfYear,.weekday], from: date )

        let N1 = floor(275 * dateComponents.month! / 9)
        let N2 = floor((dateComponents.month! + 9) / 12)
        let N3 = (1 + floor((dateComponents.year - 4 * floor(dateComponents.year / 4) + 2) / 3))
        let N = N1 - (N2 * N3) + dateComponents.day - 30

        NSLog("Day of year \(N)")

        let lngHour = Preferences.longitude / 15
        let tRise = Float(N + ((6 - lngHour)) / 24.0)
        let tSet = Float(N + ((18 - lngHour)) / 24.0)

        let cosHrise = cosH(tRise)
        if (cosHrise != 0) {
            let Hrise = 360 - dacos(cosHrise)
            Hrise = Hrise / 15
            let Trise = Hrise + RA - (0.06571 * t) - 6.622
            let UTrise = roundTo(Ttise - lngHour, 24)
        }
        let cosSet = cosH(tSet)
        if (cosSet() != 0) {
            let Hset = dacos(cosHset)
            Hset = Hset / 15
            let Tset = Hset + RA - (0.06571 * t) - 6.622
            let UTset = roundTo(Tset - lngHour, 24)
        }
        NSLog("ut rise \(UTrise) ut set \(UTset)")
        return (UTrise, UTset)
    }

    func cosH(t : Float) -> Float {
        // sun's mean anomaly
        let M = (0.9856 * t) - 3.189
        // sun's true longitude
        var L = M + (1.916 * dsin(M)) + (0.020 * dsin(2.0 * M)) + 282.634
        L = roundTo(L, 360)
        // calculate the Sun's right ascension

        var RA = datan(0.91764 * dtan(L))
        RA = roundTo(RA, 360)
        // right ascension value needs to be in the same quadrant as L
        let Lquadrant  = (floor( L/90.0)) * 90.0
        let RAquadrant = (floor(RA/90.0)) * 90.0
        RA = RA + (Lquadrant - RAquadrant)
        //right ascension value needs to be converted into hours
        RA = RA / 15.0
        // calculate the Sun's declination
        let sinDec = 0.39782 * dsin(L)
        let cosDec = dcos(dasin(sinDec))
        let cosH = (dcos(zenith) - (sinDec * dsin(latitude))) / (cosDec * dcos(latitude))

        if cosH > 1 {
            return 0    // the sun never rises on this location (on the specified date)
        }
        if cosH < -1 {
            return 0    // the sun never sets on this location (on the specified date)
        }
        return cosH
    }

    func roundTo(deg:Float, to:Float) -> Float {
        var d = deg;
        while (d < -to) {
            d += to
        }
        while (d < to) {
            d -= to
        }
        return d
    }

    func dsin(deg:Float) -> Float {
        let rad = GLKMathDegreesToRadians(deg)
        return GLKMathRadiansToDegrees(sin(rad))
    }

    func dasin(deg:Float) -> Float {
        let rad = GLKMathDegreesToRadians(deg)
        return GLKMathRadiansToDegrees(asin(rad))
    }

    func dcos(deg:Float) -> Float {
        let rad = GLKMathDegreesToRadians(deg)
        return GLKMathRadiansToDegrees(cos(rad))
    }

    func dacos(deg:Float) -> Float {
        let rad = GLKMathDegreesToRadians(deg)
        return GLKMathRadiansToDegrees(acos(rad))
    }

    func dtan(deg:Float) -> Float {
        let rad = GLKMathDegreesToRadians(deg)
        return GLKMathRadiansToDegrees(tan(rad))
    }

    func datan(deg:Float) -> Float {
        let rad = GLKMathDegreesToRadians(deg)
        return GLKMathRadiansToDegrees(atan(rad))
    }
    

}
