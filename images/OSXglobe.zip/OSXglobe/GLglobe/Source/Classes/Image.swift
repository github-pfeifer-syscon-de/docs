//
//  Image.swift
//  GLEssentials
//
//  Created by Roland Pfeifer on 06/11/21.
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation
import GLKit
import CoreImage
import CoreGraphics

public class Image {
    var width = GLuint()
    var height = GLuint()
    var format = GLenum()
    var type = GLenum()
    var rowByteSize = GLuint()
    var data : [UInt8]?
    //var data : UnsafeMutablePointer<GLubyte>

    init(width: GLuint, height: GLuint) {
        self.width = width
        self.height = height
        self.rowByteSize = self.width * 4
        let bytes = Int(self.height * self.rowByteSize)
        self.data = Array(repeating: UInt8(0), count: bytes)
        //self.data = UnsafeMutablePointer(mutating:Array(repeating: UInt8(0), count: bytes))
        self.format = GLenum(GL_RGBA)
        self.type = GLenum(GL_UNSIGNED_BYTE)
    }

    convenience init(filepathString:String, flipVertical:Bool = false) {
        #if TARGET_IOS
            var imageClass = UIImage.init(contentsOfFile: filepathString)
        #else
            let nsimage = NSImage(contentsOfFile: filepathString)
            let imageClass = NSBitmapImageRep(data:(nsimage?.tiffRepresentation)!)
        #endif
        if let cgImage = imageClass?.cgImage {
            self.init(width: GLuint(cgImage.width), height: GLuint(cgImage.height))
           
            let colorSpace = cgImage.colorSpace  // better than CGColorSpace(name: CGColorSpace.sRGB)  ?
            let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.noneSkipLast.rawValue)

            if let ctx = CGContext(data: UnsafeMutablePointer(mutating: self.data), width:Int(self.width), height: Int(self.height), bitsPerComponent: 8, bytesPerRow: Int(self.rowByteSize), space: colorSpace!, bitmapInfo: bitmapInfo.rawValue) {
                ctx.setBlendMode(CGBlendMode.copy)
                if (flipVertical) {
                    ctx.translateBy(x: 0.0, y: CGFloat(self.height));
                    ctx.scaleBy(x: 1.0, y: -1.0);
                }
                let rect = CGRect(x:0.0, y:0.0, width:CGFloat(self.width), height:CGFloat(self.height))
                ctx.draw(cgImage,in:rect)
                ctx.flush()
            }
            else {
                NSLog("Error creating cgContext")
            }
        }
        else {
            self.init(width: GLuint(0), height: GLuint(0))
            NSLog("Error on getting cgImage")
        }
    }
    
    func buildTexture() -> GLuint {
        var texName = GLuint()
        //texName = imgBuildTexture(self.format, self.type, self.width, self.height, UnsafePointer<GLubyte>(self.data))
        // Create a texture object to apply to model
        glGenTextures(1, &texName);
        glBindTexture(GLenum(GL_TEXTURE_2D), texName);
                  // Set up filter and wrap modes for this texture object
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_S), GL_CLAMP_TO_EDGE);
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_WRAP_T), GL_CLAMP_TO_EDGE);
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MAG_FILTER), GL_LINEAR);
        glTexParameteri(GLenum(GL_TEXTURE_2D), GLenum(GL_TEXTURE_MIN_FILTER), GL_LINEAR_MIPMAP_LINEAR);
        
        // Indicate that pixel rows are tightly packed
        //  (defaults to stride of 4 which is kind of only good for
        //  RGBA or FLOAT data types)
        glPixelStorei(GLenum(GL_UNPACK_ALIGNMENT), 1);
        
        // Allocate and load image data into texture
        glTexImage2D(GLenum(GL_TEXTURE_2D), 0, GLint(self.format), GLsizei(self.width), GLsizei(self.height), 0, self.format, self.type, UnsafeRawPointer(self.data))
        
        // Create mipmaps for this texture for better image quality
        glGenerateMipmap(GLenum(GL_TEXTURE_2D));

        self.data = nil // data no longer needed
        return texName;
    }

}
