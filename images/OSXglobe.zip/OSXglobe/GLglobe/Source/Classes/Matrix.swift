//
//  Matrix.swift
//  GLEssentials
//
//  Created by Roland Pfeifer on 05/11/21.
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation
import GLKit

public class Matrix {
    var mtx = Array<Float>(repeating: 0.0, count: 16)
    public init() {
        mtx[ 0] = 1.0
        mtx[ 5] = 1.0
        mtx[10] = 1.0
        mtx[15] = 1.0
    }
    public convenience init(offsX: Float, offsY: Float, offsZ: Float) {
        self.init()
        mtx[12] = offsX
        mtx[13] = offsY
        mtx[14] = offsZ
    }
     public convenience init(eye:Vect3, center:Vect3, up:Vect3) {
        self.init()
        let f = center.subtract(sub:eye)
        f.normalize()
        let s = f.cross(product:up)
        s.normalize()
        let u = s.cross(product:f)
        
        mtx[0] = s.x;  mtx[4] = s.y;  mtx[8] = s.z;    mtx[12] = -s.dot(product:eye);
        mtx[1] = u.x;  mtx[5] = u.y;  mtx[9] = u.z;    mtx[13] = -u.dot(product:eye);
        mtx[2] = -f.x; mtx[6] = -f.y; mtx[10] = -f.z;  mtx[14] =  f.dot(product:eye);
    }
    public convenience init(fov:Float,aspect:Float,nearZ:Float,farZ:Float) {
        self.init()
        let f : Float = 1.0 / tan(GLKMathDegreesToRadians(fov)) / 2.0
    
        self.mtx[0] = f / aspect
        self.mtx[1] = 0.0
        self.mtx[2] = 0.0
        self.mtx[3] = 0.0
    
        self.mtx[4] = 0.0
        self.mtx[5] = f
        self.mtx[6] = 0.0
        self.mtx[7] = 0.0
    
        self.mtx[8] = 0.0
        self.mtx[9] = 0.0
        self.mtx[10] = (farZ+nearZ) / (nearZ-farZ)
        self.mtx[11] = -1.0
    
        self.mtx[12] = 0.0
        self.mtx[13] = 0.0
        self.mtx[14] = 2.0 * farZ * nearZ /  (nearZ-farZ)
        self.mtx[15] = 0.0
    }
    
    public func multiply(rhs : Matrix) -> Matrix {
    // [ 0 4  8 12 ]   [ 0 4  8 12 ]
    // [ 1 5  9 13 ] x [ 1 5  9 13 ]
    // [ 2 6 10 14 ]   [ 2 6 10 14 ]
    // [ 3 7 11 15 ]   [ 3 7 11 15 ]
    let ret = Matrix()
    ret.mtx[ 0] = mtx[ 0]*rhs.mtx[ 0] + mtx[ 4]*rhs.mtx[ 1] + mtx[ 8]*rhs.mtx[ 2] + mtx[12]*rhs.mtx[ 3];
    ret.mtx[ 1] = mtx[ 1]*rhs.mtx[ 0] + mtx[ 5]*rhs.mtx[ 1] + mtx[ 9]*rhs.mtx[ 2] + mtx[13]*rhs.mtx[ 3];
    ret.mtx[ 2] = mtx[ 2]*rhs.mtx[ 0] + mtx[ 6]*rhs.mtx[ 1] + mtx[10]*rhs.mtx[ 2] + mtx[14]*rhs.mtx[ 3];
    ret.mtx[ 3] = mtx[ 3]*rhs.mtx[ 0] + mtx[ 7]*rhs.mtx[ 1] + mtx[11]*rhs.mtx[ 2] + mtx[15]*rhs.mtx[ 3];
    
    ret.mtx[ 4] = mtx[ 0]*rhs.mtx[ 4] + mtx[ 4]*rhs.mtx[ 5] + mtx[ 8]*rhs.mtx[ 6] + mtx[12]*rhs.mtx[ 7];
    ret.mtx[ 5] = mtx[ 1]*rhs.mtx[ 4] + mtx[ 5]*rhs.mtx[ 5] + mtx[ 9]*rhs.mtx[ 6] + mtx[13]*rhs.mtx[ 7];
    ret.mtx[ 6] = mtx[ 2]*rhs.mtx[ 4] + mtx[ 6]*rhs.mtx[ 5] + mtx[10]*rhs.mtx[ 6] + mtx[14]*rhs.mtx[ 7];
    ret.mtx[ 7] = mtx[ 3]*rhs.mtx[ 4] + mtx[ 7]*rhs.mtx[ 5] + mtx[11]*rhs.mtx[ 6] + mtx[15]*rhs.mtx[ 7];
    
    ret.mtx[ 8] = mtx[ 0]*rhs.mtx[ 8] + mtx[ 4]*rhs.mtx[ 9] + mtx[ 8]*rhs.mtx[10] + mtx[12]*rhs.mtx[11];
    ret.mtx[ 9] = mtx[ 1]*rhs.mtx[ 8] + mtx[ 5]*rhs.mtx[ 9] + mtx[ 9]*rhs.mtx[10] + mtx[13]*rhs.mtx[11];
    ret.mtx[10] = mtx[ 2]*rhs.mtx[ 8] + mtx[ 6]*rhs.mtx[ 9] + mtx[10]*rhs.mtx[10] + mtx[14]*rhs.mtx[11];
    ret.mtx[11] = mtx[ 3]*rhs.mtx[ 8] + mtx[ 7]*rhs.mtx[ 9] + mtx[11]*rhs.mtx[10] + mtx[15]*rhs.mtx[11];
    
    ret.mtx[12] = mtx[ 0]*rhs.mtx[12] + mtx[ 4]*rhs.mtx[13] + mtx[ 8]*rhs.mtx[14] + mtx[12]*rhs.mtx[15];
    ret.mtx[13] = mtx[ 1]*rhs.mtx[12] + mtx[ 5]*rhs.mtx[13] + mtx[ 9]*rhs.mtx[14] + mtx[13]*rhs.mtx[15];
    ret.mtx[14] = mtx[ 2]*rhs.mtx[12] + mtx[ 6]*rhs.mtx[13] + mtx[10]*rhs.mtx[14] + mtx[14]*rhs.mtx[15];
    ret.mtx[15] = mtx[ 3]*rhs.mtx[12] + mtx[ 7]*rhs.mtx[13] + mtx[11]*rhs.mtx[14] + mtx[15]*rhs.mtx[15];
    
    return ret;
    }
    
    
    public func toArray() -> [Float] {
         return mtx
    }
    
}

public class Matrix3 {
    var mtx = Array<Float>(repeating: 0.0, count: 9)

    public init() {
        mtx[0] = 1.0
        mtx[4] = 1.0
        mtx[8] = 1.0
    }

    public init(src : Matrix) {
    mtx[0] = src.mtx[0]
    mtx[1] = src.mtx[1]
    mtx[2] = src.mtx[2]
    mtx[3] = src.mtx[4]
    mtx[4] = src.mtx[5]
    mtx[5] = src.mtx[6]
    mtx[6] = src.mtx[8]
    mtx[7] = src.mtx[9]
    mtx[8] = src.mtx[10]
    }
    
    public func toArray() -> [Float] {
        return mtx
    }

}

// Some helpers for GLK library functions
func GLKMatrix4MakeLookAtVec(_ eye: GLKVector3, _ center: GLKVector3, _ up: GLKVector3) -> GLKMatrix4 {
    return GLKMatrix4MakeLookAt(eye.x, eye.y, eye.z, center.x, center.y, center.z, up.x, up.y, up.z)
}
extension GLKMatrix3 {
    func toArray() -> [Float] {
        var arr = [Float]()
        arr.append(m00)
        arr.append(m01)
        arr.append(m02)
        arr.append(m10)
        arr.append(m11)
        arr.append(m12)
        arr.append(m20)
        arr.append(m21)
        arr.append(m22)
        return arr
    }
    func toGL(unifomIdx: GLint) {
        glUniformMatrix3fv(unifomIdx, 1, GLboolean(GL_FALSE), toArray())
    }
}
extension GLKMatrix4 {
    func toArray() -> [Float] {
        var arr = [Float]()
        arr.append(m00)
        arr.append(m01)
        arr.append(m02)
        arr.append(m03)
        arr.append(m10)
        arr.append(m11)
        arr.append(m12)
        arr.append(m13)
        arr.append(m20)
        arr.append(m21)
        arr.append(m22)
        arr.append(m23)
        arr.append(m30)
        arr.append(m31)
        arr.append(m32)
        arr.append(m33)
        return arr
    }
    func toGL(unifomIdx: GLint) {
        glUniformMatrix4fv(unifomIdx, 1, GLboolean(GL_FALSE), toArray())
    }
}
