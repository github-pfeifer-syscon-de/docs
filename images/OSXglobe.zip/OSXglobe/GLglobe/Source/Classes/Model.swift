//
//  Model.swift
//  GLEssentials
//
//  Created by Roland Pfeifer on 06/11/21.
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation
import GLKit

public class Buffer {
    var size : GLint
    var type : GLenum   // shoud match T
    var data = Array<GLfloat>()
    var count = GLsizei()
    init(size: GLint, type: GLenum = GLenum(GL_FLOAT)) {
        self.size = size
        self.type = type
    }

    func freeArray() {
        count = GLsizei(data.count)
        data.removeAll()
    }

    // make count avail before and after freeArray was called
    var counts: GLsizei {
        return max(count, GLsizei(data.count))
    }

    public func toGL(arr:[Float]) {
        for f in arr {
            data.append(GLfloat(f))
        }
    }

    var arraySize: GLsizei {
        return Model.getGLTypeSize(type: type) * self.counts
    }

    var stride: GLsizei {
        return Model.getGLTypeSize(type: type) * size
    }

    func BUFFER_OFFSET(_ i: Int) -> UnsafeRawPointer? {
        return UnsafeRawPointer(bitPattern: i)
    }

    func createVertexAttribPointer(posIdx: GLuint, normalize: GLboolean = GLboolean(GL_FALSE)) -> GLuint {
        var bufferName : GLuint = 0

        // Create a vertex buffer object (VBO) to store positions
        glGenBuffers(1, &bufferName)
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), bufferName)

        //NSLog("createVertexAttribPointer idx \(posIdx) buffer \(bufferName) array \(self.arraySize) size \(self.size) stride \(self.stride)")
        // Allocate and load position data into the VBO
        glBufferData(GLenum(GL_ARRAY_BUFFER), GLsizeiptr(self.arraySize), self.data, GLenum(GL_STATIC_DRAW))

        // Enable the position attribute for this VAO
        glEnableVertexAttribArray(GLenum(posIdx))

        // Set up parmeters for position attribute in the VAO including,
        //  size, type, stride, and offset in the currenly bound VAO
        // This also attaches the position VBO to the VAO
        glVertexAttribPointer(posIdx,		// What attibute index will this array feed in the vertex shader (see buildProgram)
            self.size,	 // How many elements are there per position?
            self.type,	 // What is the type of this data?
            normalize,	 // Do we want to normalize this data (0-1 range for fixed-pont types)
            self.stride, // What is the stride (i.e. bytes between positions)?
            BUFFER_OFFSET(0));	// What is the offset in the VBO to the position data?
        return bufferName;
    }

    func vertexAttribPointer(posIdx: GLuint, normalize: GLboolean = GLboolean(GL_FALSE)) {
        glEnableVertexAttribArray(posIdx)
        // Set up parmeters for position attribute in the VAO including,
        //  size, type, stride, and offset in the currenly bound VAO
        // This also attaches the position array in memory to the VAO
        glVertexAttribPointer(posIdx,  // What attibute index will this array feed in the vertex shader? (also see buildProgram)
        self.size,   // How many elements are there per position?
        self.type,   // What is the type of this data
        normalize,	 // Do we want to normalize this data (0-1 range for fixed-pont types)
        self.stride, // What is the stride (i.e. bytes between positions)?
        self.data);  // Where is the position data in memory?
    }

}

// base model
public class Model { // handling templats is worksome ...
    var position = Buffer(size: 3)
    var texcoord = Buffer(size: 2)
    var normal = Buffer(size: 3)
    var color = Buffer(size: 3)

    var elementType: GLenum    // shoud match S
    var elements = Array<GLushort>()
    var elementsCount = GLsizei()
    var primType: GLenum
    var vaoName: GLuint = 0
    var useVBOs: Bool = false

    init() {
        // set some useful defaults if you disagree you may change it later
        self.elementType = GLenum(GL_UNSIGNED_SHORT)
        self.primType = GLenum(GL_TRIANGLES)
    }

    deinit {
        if vaoName > 0 {
            //NSLog("Destroy model \(type(of: self))")
            destroyVAO()
            //getGLError("Delete info VAO")
        }
    }

    func draw() {
        // Bind our vertex array object
        glBindVertexArray(vaoName);
        if(useVBOs) {
            glDrawElements(GLenum(primType), GLsizei(numElements), elementType, nil)
        }
        else {
            glDrawElements(GLenum(primType), GLsizei(numElements), elementType, elements)
        }
    }

    var numVertcies : Int {
        return Int(position.counts) / Int(position.size)
    }
    
    // from the point on we uploaded the arrays we can clear our copy
    func freeArray() {
        // save counts so later on drawing we have them available
        //   as when freeArray is called the arrays are lost
        position.freeArray()
        normal.freeArray()
        texcoord.freeArray()
        color.freeArray()
        self.elementsCount = GLsizei(elements.count)
        elements.removeAll()
    }

    var elementArraySize : GLsizei {
        return Model.getGLTypeSize(type: elementType) * max(elementsCount, GLsizei(elements.count))
    }
    var numElements : GLuint {
        return GLuint(elementsCount)
    }
    public func toGLelements(arr:[Int], to:inout[GLushort]) {
        for f in arr {
            to.append(GLushort(f))
        }
    }

    public static func getGLTypeSize(type: GLenum) -> GLsizei {
        let itype = Int32(type)
        var size : Int
        switch (itype) {
        case GL_BYTE:
            size = MemoryLayout<GLbyte>.size
            break
        case GL_UNSIGNED_BYTE:
            size = MemoryLayout<GLubyte>.size
            break
        case GL_SHORT:
            size = MemoryLayout<GLshort>.size
            break
        case GL_UNSIGNED_SHORT:
            size = MemoryLayout<GLushort>.size
            break
        case GL_INT:
            size = MemoryLayout<GLint>.size
            break
        case GL_UNSIGNED_INT:
            size = MemoryLayout<GLuint>.size
            break
        case GL_FLOAT:
            size = MemoryLayout<GLfloat>.size
            break
        default:
            size = 0
            break
        }
        return GLsizei(size)
    }

    // used to bind program
    func positionInIdx() -> GLuint {
        return GLuint(0)
    }

    func hasNormal() -> Bool {
        return normal.counts > 0
    }

    func normalInIdx() -> GLuint {
        return positionInIdx() + GLuint(hasNormal() ? 1 : 0)
    }

    func hasTexcoord() -> Bool {
        return texcoord.counts > 0
    }

    func texcoordInIdx() -> GLuint  {
        return normalInIdx() + GLuint(hasTexcoord() ? 1 : 0)
    }

    func hasColor() -> Bool {
        return color.counts > 0
    }

    func colorInIdx() -> GLuint  {
        return texcoordInIdx() + GLuint(hasColor() ? 1 : 0)
    }

    func buildVAO(useVBOs: Bool) -> GLuint {
        self.useVBOs = useVBOs
        // Create a vertex array object (VAO) to cache model parameters
        glGenVertexArrays(1, &vaoName)
        glBindVertexArray(vaoName)
        
        if(useVBOs) {
            var posBufferName = position.createVertexAttribPointer(posIdx: positionInIdx())
            
            if (hasNormal()) {
                var normalBufferName = normal.createVertexAttribPointer(posIdx: normalInIdx())
                
            }
            
            if (hasTexcoord()) {
                var texcoordBufferName = texcoord.createVertexAttribPointer(posIdx: texcoordInIdx())
            }

            if (hasColor()) {
                var colorBufferName = color.createVertexAttribPointer(posIdx: colorInIdx())

            }
            var elementBufferName: GLuint = 0
            
            // Create a VBO to vertex array elements
            // This also attaches the element array buffer to the VAO
            glGenBuffers(1, &elementBufferName)
            glBindBuffer(GLenum(GL_ELEMENT_ARRAY_BUFFER), elementBufferName)
            
            // Allocate and load vertex array element data into VBO
            glBufferData(GLenum(GL_ELEMENT_ARRAY_BUFFER), GLsizeiptr(self.elementArraySize), self.elements, GLenum(GL_STATIC_DRAW))

            //If we're using VBOs we can destroy all this memory since buffers are
            // loaded into GL and we've saved anything else we need
            self.freeArray()
        }
        else {
            // Enable the position attribute for this VAO
            position.vertexAttribPointer(posIdx: positionInIdx())

            if(hasNormal()) {
                normal.vertexAttribPointer(posIdx: normalInIdx())
            }
            
            if (hasTexcoord()) {
                texcoord.vertexAttribPointer(posIdx: texcoordInIdx())
            }

            if (hasColor()) {
                color.vertexAttribPointer(posIdx: colorInIdx())
            }
        }
        
        return vaoName;
    }

    @objc public func destroyVAO() {
        if vaoName > 0 {
            var bufName = GLuint()
            var ibufName = GLint()

            // Bind the VAO so we can get data from it
            glBindVertexArray(vaoName);

            // For every possible attribute set in the VAO
            for index in 0..<16 {
                // Get the VBO set for that attibute
                glGetVertexAttribiv(GLuint(index), GLenum(GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING), &ibufName);
                bufName = GLuint(ibufName)
                // If there was a VBO set...
                if(bufName > 0) {
                    //...delete the VBO
                    glDeleteBuffers(1, &bufName);
                }
            }

            // Get any element array VBO set in the VAO
            glGetIntegerv(GLenum(GL_ELEMENT_ARRAY_BUFFER_BINDING), &ibufName)

            // If there was a element array VBO set in the VAO
            if(bufName > 0)  {
                //...delete the VBO
                glDeleteBuffers(1, &bufName)
            }

            // Finally, delete the VAO
            var ivaoName = vaoName
            glDeleteVertexArrays(1, &ivaoName)
            vaoName = 0
        }
    }

}

class SphereModel : Model {
    public init(useVBOs: Bool, radius : Double, sectors : Int) {
        super.init()
        
        let rings = sectors
        let PI_2 = (Double.pi / 2.0)
        let _2PI = (2.0 * Double.pi)
        
        // as these values are expensive and will get used often precalculate
        var sinLon = Array<Double>(repeating: 0.0, count: sectors)
        var cosLon = Array<Double>(repeating: 0.0, count: sectors)
        var tCosLon = Array<Double>(repeating: 0.0, count: sectors)
        var tSinLon = Array<Double>(repeating: 0.0, count: sectors)
        for s in 0..<sectors {
            let sms = Double(s) / Double(sectors-1)
            let lon = _2PI * sms
            sinLon[s] = sin(lon);
            cosLon[s] = cos(lon);
            let tlon = lon + PI_2       // tangent is the normal at lon offset 90°
            tSinLon[s] = sin(tlon);
            tCosLon[s] = cos(tlon);
        }
        
        for r in 0..<rings {
            let rmr = Double(r) / Double(rings-1)
            let lat = Double.pi * rmr
            let sinLat = sin(lat)    // the trig(double) is more accurate than needed (but as we precalculate values that shoud not matter)
            let sinLat2 = sin(-PI_2 + lat) // -PI_2 makes the latitudes to mach equator
            //double const btlat = lat + M_PI_2;    // bitangent is the normal at lat offset 90°
            //double const btSinLat = sin(btlat);
            //double const btSinLat2 = sin(-M_PI_2 + btlat);
            for s in 0..<sectors {
                let sms = Double(s) / Double(sectors-1)
                let x = sinLon[s] * sinLat    // match definition of texture at 180° from greenwich and wrap (date border)
                let y = sinLat2
                let z = cosLon[s] * sinLat
                
                self.normal.data.append(GLfloat(x))
                self.normal.data.append(GLfloat(y))
                self.normal.data.append(GLfloat(z))
                self.texcoord.data.append(GLfloat(sms))    // u matches our geometry above
                self.texcoord.data.append(GLfloat(rmr))    // v
                self.position.data.append(GLfloat(x * radius))
                self.position.data.append(GLfloat(y * radius))
                self.position.data.append(GLfloat(z * radius))
            }
        }
        
        for r in 0..<rings {
            for s in 0..<sectors {
                let rs = r * sectors
                let rs1 = (r+1) * sectors
                let i0 = GLushort(rs + s)
                let i1 = GLushort(rs + (s+1))
                let i2 = GLushort(rs1 + (s+1))
                let i3 = GLushort(rs1 + s)
                self.elements.append(i0)    // first triangle
                self.elements.append(i1)
                self.elements.append(i2)
                self.elements.append(i2)    // second triangle
                self.elements.append(i3)
                self.elements.append(i0)
            }
        }
        buildVAO(useVBOs: useVBOs)
    }

}

class QuadModel : Model {
    public init(useVBOs: Bool) {
        super.init()
  
        position.toGL(
            arr:  [-200.0, 0.0, -200.0,
                    200.0, 0.0, -200.0,
                    200.0, 0.0,  200.0,
                   -200.0, 0.0,  200.0 ])
         //toGL(
         //   arr:  [ 0.0,  1.0,
         //           1.0,  1.0,
         //           1.0,  0.0,
         //           0.0,  0.0 ],
         //   to: &self.texcoords)
         normal.toGL(
            arr:  [ 0.0, 0.0, 1.0,
                    0.0, 0.0, 1.0,
                    0.0, 0.0, 1.0,
                    0.0, 0.0, 1.0 ])
         toGLelements(
            arr:  [ 0, 2, 1,
                    0, 3, 2 ],
            to: &self.elements)

        buildVAO(useVBOs: useVBOs)
    }
}


class TextModel : Model {
    public init(useVBOs: Bool, width: Float, height: Float) {
        super.init()

        let modelWidth = width / 2.0
        let modelHeight = height / 2.0
        position.toGL(
            arr:  [   0.0,              0.0, 0.0,
                    modelWidth,         0.0, 0.0,
                    modelWidth, modelHeight, 0.0,
                      0.0,      modelHeight, 0.0 ])
        texcoord.toGL(
            arr:  [ 0.0,  0.0,
                    1.0,  0.0,
                    1.0,  1.0,
                    0.0,  1.0 ])
        //toGL(
        //    arr:  [ 0.0, 0.0, 1.0,
        //            0.0, 0.0, 1.0,
        //            0.0, 0.0, 1.0,
        //            0.0, 0.0, 1.0 ],
        //    to: &self.normals)
        toGLelements(
            arr:  [ 0, 1, 2,
                    0, 2, 3 ],
            to: &self.elements)

        buildVAO(useVBOs: useVBOs)
    }
}

class LocationModel :Model {
    let tzs: [Tz]
    public init(useVBOs: Bool, tzs: [Tz], radius: GLfloat) {
        self.tzs = tzs
        super.init()
        self.primType = GLenum(GL_POINTS)
        //let PI2 = (2.0 * Float.pi)
        for tz in tzs {
            let xyz:(x: Float,y: Float,z: Float) = LocationModel.toXYZ(lat: tz.lat, lon: tz.lon)

            self.position.data.append(GLfloat(xyz.x * radius))
            self.position.data.append(GLfloat(xyz.y * radius))
            self.position.data.append(GLfloat(xyz.z * radius))
            //self.color.data.append(GLfloat(1.0))
            //self.color.data.append(GLfloat(0.0))
            //self.color.data.append(GLfloat(0.0))
            self.elements.append(GLushort(self.elements.count)) // this shoud not be need but to comply to other drawings
        }
        buildVAO(useVBOs: useVBOs)
    }

    static func toXYZ(lat: Float, lon: Float) -> (x: Float,y: Float,z: Float) {
        let PI_2 = (Float.pi / 2.0)
        let lon = GLKMathDegreesToRadians(lon + 180.0)  // +180 to account for texture starting in pacific but here Greenwich is the reference
        let lat = GLKMathDegreesToRadians(90.0 + lat)  // to make -90..90 range go from 0..180
        //NSLog("tz lon \(tz.lon!) rad \(lon) lat \(tz.lat) rad \(lat)")
        let sinLat = sin(lat)
        let x = sin(lon) * sinLat
        let y = sin(-PI_2 + lat)
        let z = cos(lon) * sinLat
        return (x,y,z)
    }

    override func freeArray() {
        //position.freeArray() keep those as we need to calculate tooltips
        normal.freeArray()
        texcoord.freeArray()
        color.freeArray()
        self.elementsCount = GLsizei(elements.count)
        elements.removeAll()
    }

    func proximity(mouse: NSPoint, mvp: GLKMatrix4, viewWidth: GLuint, viewHeight: GLuint, dist: inout Float, distNearest: inout Float, distFarest: inout Float) -> Tz? {
        let sensX = 5.0 / Float(viewWidth)
        let sensY = 5.0 / Float(viewHeight)
        let mouseClipX = -1.0 + ((Float(mouse.x) / Float(viewWidth)) * 2.0)
        let mouseClipY = -1.0 + ((Float(mouse.y) / Float(viewHeight)) * 2.0)
        var match: Tz? = nil
        //NSLog("proximity mouse \(mouseClipX) \(mouseClipY) sens \(sensX) \(sensY)")
        var i = 0
        while i < self.tzs.count {
            let pi = i * 3
            let pos = GLKVector4Make(self.position.data[pi], self.position.data[pi+1], self.position.data[pi+2], 1.0)
            let view = GLKMatrix4MultiplyVector4(mvp, pos)
            let clip = GLKVector3Make(view.x / view.w, view.y / view.w, view.z / view.w)

            //if  tzs[i].name.contains("Berlin") {
            //    NSLog("Pos \(tzs[i].name) \(pos.x) \(pos.y) \(pos.z)")
            //    NSLog("View \(view.x) \(view.y) \(view.z) \(view.w)")
            //    NSLog("Clip \(clip.x) \(clip.y) \(clip.z)")
            //}
            if abs(mouseClipX - clip.x) < sensX &&
                abs(mouseClipY - clip.y) < sensY {
                if dist < clip.z {  // look for closest to eye 
                    match = tzs[i]
                    dist = clip.z
                }
                //NSLog("Hit \(tzs[i].name)")
            }
            if distNearest < clip.z {
                distNearest = clip.z
            }
            if distFarest > clip.z {
                distFarest = clip.z
            }
            i += 1
        }
        return match
    }
}
