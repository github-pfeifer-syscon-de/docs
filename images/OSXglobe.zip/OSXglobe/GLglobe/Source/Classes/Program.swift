//
//  Program.swift
//  GLglobe
//
//  Created by Roland Pfeifer on 07/11/21.
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation
import GLKit

class Program {
    var prgName = GLuint()
    
    init(vertexSource : String, fragmentSource: String, model: Model) {
        var logLength = GLint()
        var status = GLint()
        
        // Determine if GLSL version 140 is supported by this context.
        //  We'll use this info to generate a GLSL shader source string
        //  with the proper version preprocessor string prepended
        var glLanguageVersion : Float
        
        let versionPtr = glGetString(GLenum(GL_SHADING_LANGUAGE_VERSION))
        let versionString = String(cString: versionPtr!)
        #if TARGET_IOS
            let versionComponents = versionString.components(separedBy: " ")
            //sscanf((char *), "OpenGL ES GLSL ES %f", &glLanguageVersion);
            glLanguageVersion = Float(versionComponents[versionComponents.count - 1])
        #else
            glLanguageVersion = Float(versionString)!
        #endif
        
        // GL_SHADING_LANGUAGE_VERSION returns the version standard version form
        //  with decimals, but the GLSL version preprocessor directive simply
        //  uses integers (thus 1.10 should 110 and 1.40 should be 140, etc.)
        //  We multiply the floating point number by 100 to get a proper
        //  number for the GLSL preprocessor directive
        let version = GLuint(100 * glLanguageVersion)
        
        
        // Create a program object
        prgName = glCreateProgram()
        
        // Indicate the attribute indicies on which vertex arrays will be
        //  set with glVertexAttribPointer
        //  See buildVAO to see where vertex arrays are actually set
        glBindAttribLocation(prgName, model.positionInIdx(), "inPosition")
        
        if (model.hasNormal()) {
            glBindAttribLocation(prgName, model.normalInIdx(), "inNormal")
        }
        if (model.hasTexcoord()) {
            glBindAttribLocation(prgName, model.texcoordInIdx(), "inTexcoord")
        }
        if (model.hasColor()) {
            glBindAttribLocation(prgName, model.colorInIdx(), "inColor")
        }

        //////////////////////////////////////
        // Specify and compile VertexShader //
        //////////////////////////////////////
        
        
        // Prepend our vertex shader source string with the supported GLSL version so
        //  the shader will work on ES, Legacy, and OpenGL 3.2 Core Profile contexts
        var sourceString = "#version \(version)\n\(vertexSource)"
        
        let vertexShader = compileShader(code: sourceString, shaderType: GLenum(GL_VERTEX_SHADER))
        if (vertexShader == 0) {
            return
        }
        
        // Attach the vertex shader to our program
        glAttachShader(prgName, vertexShader)
        
        // Delete the vertex shader since it is now attached
        // to the program, which will retain a reference to it
        glDeleteShader(vertexShader)
        
        /////////////////////////////////////////
        // Specify and compile Fragment Shader //
        /////////////////////////////////////////
        
        
        // Prepend our fragment shader source string with the supported GLSL version so
        //  the shader will work on ES, Legacy, and OpenGL 3.2 Core Profile contexts
        sourceString = "#version \(version)\n\(fragmentSource)"
        
        let fragShader = compileShader(code: sourceString, shaderType: GLenum(GL_FRAGMENT_SHADER))
        if (fragShader == 0) {
            return
        }
        
        // Attach the fragment shader to our program
        glAttachShader(prgName, fragShader)
        
        // Delete the fragment shader since it is now attached
        // to the program, which will retain a reference to it
        glDeleteShader(fragShader);
        
        //////////////////////
        // Link the program //
        //////////////////////
        
        glLinkProgram(prgName)
        glGetProgramiv(prgName, GLenum(GL_INFO_LOG_LENGTH), &logLength);
        if (logLength > 0) {
            let info: [GLchar] = Array(repeating: GLchar(0), count: Int(logLength))
            var lenActual: GLsizei = 0
            glGetProgramInfoLog(prgName, logLength, &lenActual, UnsafeMutablePointer(mutating: info))
            let data = Data(bytes: info, count: Int(lenActual))
            let log = String(data: data, encoding: String.Encoding.utf8)!
            NSLog("Program link log:\n\(log)\n")
        }
        
        glGetProgramiv(prgName, GLenum(GL_LINK_STATUS), &status)
        if (status == 0) {
            NSLog("Failed to link program")
            return
        }
        
        glValidateProgram(prgName);
        
        glGetProgramiv(prgName, GLenum(GL_VALIDATE_STATUS), &status);
        if (status == 0) {
            // 'status' set to 0 here does NOT indicate the program itself is invalid,
            //   but rather the state OpenGL was set to when glValidateProgram was called was
            //   not valid for this program to run (i.e. Given the CURRENT openGL state,
            //   draw call with this program will fail).  You may still be able to use this
            //   program if certain OpenGL state is set before a draw is made.  For instance,
            //   'status' could be 0 because no VAO was bound and so long as one is bound
            //   before drawing with this program, it will not be an issue.
            NSLog("Program cannot run with current OpenGL State");
        }
        
        glGetProgramiv(prgName, GLenum(GL_INFO_LOG_LENGTH), &logLength);
        if (logLength > 0) {
            let info: [GLchar] = Array(repeating: GLchar(0), count: Int(logLength))
            var lenActual: GLsizei = 0
            glGetProgramInfoLog(prgName, logLength, &lenActual, UnsafeMutablePointer(mutating: info))
            let data = Data(bytes: info, count: Int(lenActual))
            let log = String(data: data, encoding: String.Encoding.utf8)!
            NSLog("Program validate log:\n\(log)\n")
        }
        
        glUseProgram(prgName)
    }

    deinit {
        if prgName > 0 {
            glDeleteProgram(prgName)
            prgName = 0
        }
    }

    
    func compileShader(code: String, shaderType: GLenum) -> GLuint {
        let shader = glCreateShader(shaderType)
        
        var cStringSource = (code as NSString).utf8String
        //let stringfromutf8string = String.fromCString(cStringSource!)
        
        glShaderSource(shader, GLsizei(1), &cStringSource, nil)
        glCompileShader(shader);
        
        var isCompiled: GLint = 0
        glGetShaderiv(shader, GLenum(GL_COMPILE_STATUS), &isCompiled)
        
        if isCompiled == 0 {
            NSLog(getLog(shader: shader))
            return 0
        }
        
        return shader
    }
    
    func getLog(shader: GLuint) -> String {
        var infolen: GLsizei = 0
        glGetShaderiv(shader, GLenum(GL_INFO_LOG_LENGTH), &infolen)
        let info: [GLchar] = Array(repeating: GLchar(0), count: Int(infolen))
        var lenActual: GLsizei = 0
        
        glGetShaderInfoLog(shader, infolen, &lenActual, UnsafeMutablePointer(mutating: info))
        let data = Data(bytes: info, count: Int(lenActual))
        return String(data: data, encoding: String.Encoding.utf8)!
    }
    
}

class ReflectShader : Program {
    var _reflectModelViewUniformIdx = GLint()
    var _reflectProjectionUniformIdx = GLint()
    var _reflectNormalMatrixUniformIdx = GLint()
   
    init(model: Model) {
        var filePathName = Bundle.main.path(forResource:"reflect", ofType:"vsh")
        let vtxSource = Source.loadSource(filePathName: filePathName!)
    
        filePathName = Bundle.main.path(forResource:"reflect", ofType:"fsh")
        let frgSource = Source.loadSource(filePathName: filePathName!)
        
        super.init(vertexSource:vtxSource, fragmentSource:frgSource, model: model)
        
        let reflectTextureLoc : GLint = glGetUniformLocation(prgName, "reflectTexture")
        glUniform1i(reflectTextureLoc, 0)
        //NSLog(@"reflectTextureLoc %d\n", reflectTextureLoc);
        
        _reflectModelViewUniformIdx = glGetUniformLocation(prgName, "modelViewMatrix")
        if(_reflectModelViewUniformIdx < 0) {
            NSLog("No modelViewMatrix in reflection shader")
        }
        
        _reflectProjectionUniformIdx = glGetUniformLocation(prgName, "modelViewProjectionMatrix")
        if(_reflectProjectionUniformIdx < 0)   {
            NSLog("No modelViewProjectionMatrix in reflection shader")
        }
        
        _reflectNormalMatrixUniformIdx = glGetUniformLocation(prgName, "normalMatrix")
        if(_reflectNormalMatrixUniformIdx < 0)   {
            NSLog("No normalMatrix in reflection shader")
        }

    }

}

class MainShader : Program {
    var _unitDay = GLuint()
    var _unitNight = GLuint()
    var _mvpUniformIdx = GLint()
    var _lightUniformIdx = GLint()
    var _twilightUniformIdx = GLint()

    init (model: Model) {
        var filePathName = Bundle.main.path(forResource: "world", ofType:"vsh")
        let vtxSource = Source.loadSource(filePathName: filePathName!)
        
        filePathName = Bundle.main.path(forResource: "world", ofType:"fsh")
        let frgSource = Source.loadSource(filePathName: filePathName!)
        
        // Build Program
        super.init(vertexSource:vtxSource, fragmentSource:frgSource, model: model)
        
        let dayTextureLoc = glGetUniformLocation(prgName, "dayTexture")
        // Indicate that the diffuse texture will be bound to texture unit 0
        glUniform1i(dayTextureLoc, 0);
        _unitDay = GLuint(GL_TEXTURE0);
        //NSLog(@"dayTextureLoc %d unit %d\n", dayTextureLoc, _unitDay);
        
        let nightTextureLoc = glGetUniformLocation(prgName, "nightTexture")
        // Indicate that the diffuse texture will be bound to texture unit 1
        glUniform1i(nightTextureLoc, 1);
        _unitNight = GLuint(GL_TEXTURE1);
        //NSLog(@"nightTextureLoc %d unit %d\n", nightTextureLoc, _unitNight);
        
        _mvpUniformIdx = glGetUniformLocation(prgName, "modelViewProjectionMatrix")
        if(_mvpUniformIdx < 0) {
            NSLog("No modelViewProjectionMatrix in main shader")
        }
        
        _lightUniformIdx = glGetUniformLocation(prgName, "lightPosition_worldspace")
        if(_lightUniformIdx < 0) {
            NSLog("No lightPosition_worldspace in main shader")
        }

        _twilightUniformIdx = glGetUniformLocation(prgName, "twilight")
        if(_twilightUniformIdx < 0) {
            NSLog("No twilightUniformIdx in main shader")
        }
    }
}

class TextShader : Program {
    var _mvpUniformIdx = GLint()

    init (model: Model) {
        var filePathName = Bundle.main.path(forResource: "text", ofType:"vsh")
        let vtxSource = Source.loadSource(filePathName: filePathName!)

        filePathName = Bundle.main.path(forResource: "text", ofType:"fsh")
        let frgSource = Source.loadSource(filePathName: filePathName!)

        // Build Program
        super.init(vertexSource:vtxSource, fragmentSource:frgSource, model: model)

        let textTextureLoc = glGetUniformLocation(prgName, "textTexture")
        // Indicate that the diffuse texture will be bound to texture unit 0
        glUniform1i(textTextureLoc, 0);

        _mvpUniformIdx = glGetUniformLocation(prgName, "modelViewProjectionMatrix")
        if(_mvpUniformIdx < 0) {
            NSLog("No modelViewProjectionMatrix in text shader")
        }
    }
}

class LocationShader : Program {
    var _mvpUniformIdx = GLint()
    var _colorUnifomIdx = GLint()

    init (model: Model) {
        var filePathName = Bundle.main.path(forResource: "location", ofType:"vsh")
        let vtxSource = Source.loadSource(filePathName: filePathName!)

        filePathName = Bundle.main.path(forResource: "location", ofType:"fsh")
        let frgSource = Source.loadSource(filePathName: filePathName!)

        // Build Program
        super.init(vertexSource:vtxSource, fragmentSource:frgSource, model: model)

        //let textTextureLoc = glGetUniformLocation(prgName, "textTexture")
        // Indicate that the diffuse texture will be bound to texture unit 0
        //glUniform1i(textTextureLoc, 0);

        _mvpUniformIdx = glGetUniformLocation(prgName, "modelViewProjectionMatrix")
        if _mvpUniformIdx < 0 {
            NSLog("No modelViewProjectionMatrix in location shader")
        }
        _colorUnifomIdx = glGetUniformLocation(prgName, "inColor")
        if _colorUnifomIdx < 0 {
            NSLog("No inColor in location shader")
        }

    }
    
}

