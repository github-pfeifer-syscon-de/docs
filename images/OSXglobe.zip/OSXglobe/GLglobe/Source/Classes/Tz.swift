//
//  Tz.swift
//  GLglobe
//
//  Created by Roland Pfeifer on 12/11/21.
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation

class Tz {
    var country = String()
    var name = String()
    var info = String()
    var lon = Float()
    var lat = Float()
    var valid = Bool()

    init(line: String) {
        let flds = line.components(separatedBy: "\t")
        if (flds.count >= 3) {
            country = flds[0]        // for the 1970 version this might be a list
            //if (country != "DE" && country != "AD") {
            //    return;
            //}
            let coord = flds[1]
            let coord1 = coord.substring(from: coord.index(coord.startIndex, offsetBy:1))

            var n = coord1.characters.index(of: "-")
            if (n == nil) {
                n = coord1.characters.index(of: "+")
            }
            if (n != nil) {
                n = coord.index(n!, offsetBy:1)
                let slat = coord.substring(to: n!)
                let slon = coord.substring(from: n!)
                lat = dms2Decimal(dms: slat, ndeg: 3)  // even if the precision of reading it as decimal seems to be sufficient, convert dms to decimal
                lon = dms2Decimal(dms: slon, ndeg: 4)
                name = flds[2]
                if (flds.count >= 4) {
                    info = flds[3]
                }
                valid = true
                //NSLog("Tz \(country)\t\(lat!)\t\(lon!)\t\(name)\t\(info)")
                return;
            }
        }
        //NSLog("Unusable line \(line)")
    }


    // convert DegreeMinuteSecond without separator to decimal
    //   ndeg gives the places of degree including sign
    func dms2Decimal(dms: String, ndeg: Int) -> Float {
        var deg: Float = 0.0
        if dms.characters.count >= ndeg {
            let idx = dms.index(dms.startIndex, offsetBy: ndeg)
            let strdeg = dms.substring(to: idx)
            deg = Float(strdeg)!
            if dms.characters.count >= ndeg+2 {
                var strmm = dms.substring(from: idx)
                strmm = strmm.substring(to: dms.index(dms.startIndex, offsetBy: 2))
                var min = Float(strmm)
                if deg.isLess(than: 0.0) {
                    min = -min!;     // sign extends to all lower fields
                }
                deg += min! / 60.0
                if dms.characters.count >= ndeg+4 {
                    let sstart = dms.index(idx, offsetBy: 2)
                    let send = dms.index(idx, offsetBy: 4)
                    let strsec = dms.substring(with: sstart..<send)
                    var sec = Float(strsec)
                    if deg.isLess(than: 0.0) {
                        sec = -sec!;     // sign extends to all lower fields
                    }
                    deg += sec! / 3600.0
                }
            }
        }
        //NSLog("Converted dms \(dms) to deg \(deg)")
        return deg;
    }

    static func read(lonMin: Float, lonMax: Float) -> [Tz] {
        var tzs = Array<Tz>()
         // At least on OSX this exists
         if let aStreamReader = StreamReader(path: "/usr/share/zoneinfo/zone.tab") {    // found no zone1970.tab ...
            defer {
                aStreamReader.close()
            }
            while let line = aStreamReader.nextLine() {
                if line.substring(with: line.startIndex..<line.index(line.startIndex, offsetBy: 1)) != "#" {
                    let tz = Tz(line: line)
                    if tz.valid && tz.lon >= lonMin && tz.lon < lonMax {
                        tzs.append(tz)
                    }
                }
            }
        }
        //NSLog("lon \(lonMin)..\(lonMax) cnt \(tzs.count) ")
        return tzs
    }

        
}
