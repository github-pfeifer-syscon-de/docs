//
//  UserDefaults.swift
//  GLglobe
//
//  Created by Roland Pfeifer on 09/11/21.
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation
#if TARGET_IOS
import UIKit
#endif
extension UserDefaults {
    enum Key: String {
        case longitude = "longitude"
        case latitude = "latitude"
        case twilight = "twilight"
        case textColor = "textColor"
        case textFont = "textFont"
        case locationNight = "locationNight"
        case locationDay = "locationDay"
        case dateFormat = "dateFormat"
    }
    
    func set<T>(_ value: T, forKey key: Key) {
        set(value, forKey: key.rawValue)
    }
    
    func bool(forKey key: Key) -> Bool {
        return bool(forKey: key.rawValue)
    }
    
    func string(forKey key: Key) -> String? {
        return string(forKey: key.rawValue)
    }
    
    func integer(forKey key: Key) -> Int? {
        return integer(forKey: key.rawValue)
    }
    
    func url(forKey key: Key) -> URL? {
        return url(forKey: key.rawValue)
    }

    #if TARGET_IOS
    func color(forKey key: Key) -> UIColor? {
        if let userSelectedColorData = NSUserDefaults.standardUserDefaults().objectForKey(forKey: key.rawValue) as? NSData {
            if let userSelectedColor = NSKeyedUnarchiver.unarchiveObjectWithData(userSelectedColorData) as? UIColor {
                return userSelectedColor
            }
        }
        return nil
    }
    #else
    func color(forKey key: Key) -> NSColor? {
        if let userSelectedColorData = UserDefaults.standard.object(forKey: key.rawValue) as? NSData {
            if let userSelectedColor = NSKeyedUnarchiver.unarchiveObject(with: userSelectedColorData as Data) as? NSColor {
                return userSelectedColor
            }
        }
        return nil
    }
    #endif

    func font(forKey key: Key) -> NSFont? {
        if let fontData = UserDefaults.standard.object(forKey: key.rawValue) as? NSData {
            if let font = NSKeyedUnarchiver.unarchiveObject(with: fontData as Data) as? NSFont {
                return font
            }
        }
        return nil
    }


}
