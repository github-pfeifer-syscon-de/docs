//
//  Text.swift
//  GLglobe
//
//  Created by Roland Pfeifer on 10/11/21.
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation
import GLKit
import CoreImage
import CoreGraphics
import CoreFoundation


class Text : Image {
    static var _textProgram: TextShader?
    static let DefaultFontSize = Float(24.0)

    var _size: CGSize
    var _fontSize = Float()
    var _text: String?
    var _textModel: TextModel?
    var _timeTexName = GLuint()

    init(text:String, size:Float = DefaultFontSize) {

        self._fontSize = size
        self._text = text
        // Create Core Text font with desired size
        //let coreTextFont:CTFont = CTFontCreateWithName("HelveticaNeue" as NSString, CGFloat(size), nil) // -UltraLight   -Bold

        let paragraphStyle: NSMutableParagraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = NSTextAlignment.natural
        //let fontBoundingBox: CGRect = CTFontGetBoundingBox(coreTextFont)

        let textColor = Preferences.textColor
        // Create text with the following attributes
        let attributes: Dictionary<String, Any> = [
            NSFontAttributeName : Preferences.textFont,
            NSParagraphStyleAttributeName: paragraphStyle,
            NSForegroundColorAttributeName: CGColor(red: textColor.redComponent, green: textColor.greenComponent, blue: textColor.blueComponent, alpha: 1.0),   // defaults to black
          //  NSBackgroundColorAttributeName: CGColor(gray: 0.0, alpha: 0.0)
        ]
        let attributedString = NSMutableAttributedString(string:text, attributes:attributes)

        // Draw text (CTFramesetterCreateFrame requires a path).
        let framesetter: CTFramesetter = CTFramesetterCreateWithAttributedString(attributedString)

        let range = CFRangeMake(0, attributedString.length)
        //let fit = CFRage()
        let constr = CGSize(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude)
        _size = CTFramesetterSuggestFrameSizeWithConstraints(framesetter, range, nil, constr, nil)

        let textPath = CGMutablePath()
        textPath.addRect(CGRect(x: 0, y:0, width: _size.width, height: _size.height))
        let frame: CTFrame = CTFramesetterCreateFrame(framesetter, range, textPath, nil)

        //NSLog("Created box width \(size.width) height \(size.height) ")
        super.init(width: GLuint(_size.width), height: GLuint(_size.height))

        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB)
        let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)

        if let ctx = CGContext(data: UnsafeMutablePointer(mutating: self.data), width:Int(self.width), height: Int(self.height), bitsPerComponent: 8, bytesPerRow: Int(self.rowByteSize), space: colorSpace!, bitmapInfo: bitmapInfo.rawValue) {
            let rect = CGRect(x: 0.0, y: 0.0, width: CGFloat(_size.width), height: CGFloat(_size.height))
            ctx.setBlendMode(CGBlendMode.normal)
            //ctx.setFillColor(gray: 1.0, alpha: 1.0)
            //ctx.fill(rect)
            ctx.clear(rect)     // this will do nothing
            if (true) {
                ctx.translateBy(x: 0.0, y: CGFloat(self.height));
                ctx.scaleBy(x: 1.0, y: -1.0);
            }
            //ctx.setStrokeColor(gray: 0.1, alpha: 1.0) // doesnt change anything see attributes above
            //ctx.setFillColor(CGColor.clear)
            //ctx.setStrokeColor(CGColor.white)
            //ctx.setLineWidth(5.0)
            //ctx.beginPath()
            //ctx.move(to: CGPoint(x: 0, y: 0))
            //ctx.addLine(to: CGPoint(x: size.width, y: size.height))
            //ctx.move(to: CGPoint(x: size.width, y: 0))
            //ctx.addLine(to: CGPoint(x: 0, y: size.height))
            //ctx.strokePath()

            CTFrameDraw(frame, ctx)
            ctx.flush()

            // last resort
            //for y in 0..<Int(size.height) {
            //    let rowAddr = y * 4 * Int(size.width)
            //    for x in 0..<Int(size.width) {
            //        let r = self.data?[rowAddr + x * 4]
            //        let g = self.data?[rowAddr + x * 4 + 1]
            //        let b = self.data?[rowAddr + x * 4 + 2]
            //        if r == 0 && g == 0 && b == 0 {
            //            self.data?[rowAddr + x * 4 + 3] = 0
            //        }
            //    }
            //}           
            //if model == nil {
            _textModel = TextModel(useVBOs: true, width: Float(_size.width), height: Float(_size.height))     // create to match changing text and size
            //model.buildVAO()
            //getGLError("loadVAO text")

            _timeTexName = buildTexture()
            self.data = nil     // data no longer needed
        }
        else {
            NSLog("Error creating cgContext")
        }
    }

    deinit {
        _textModel = nil
        if _timeTexName > 0 {
            glDeleteTextures(1, &_timeTexName)
            _timeTexName = 0
        }
    }

    func draw() {
        if _textModel != nil {
            _textModel?.draw()
        }
        else {
            NSLog("try drawing unallocated text \(_text)! ")
        }
    }

    static func create(text: inout Text?, txt: String, size: Float = DefaultFontSize) {
        if text == nil || text?._text == nil || text?._text != txt || text?._fontSize != size {
            text = Text(text: txt, size: size)

            if _textProgram == nil {
                _textProgram = TextShader(model: (text?._textModel!)!)
                //getGLError("setup text shader")
            }

            glActiveTexture(GLenum(GL_TEXTURE0))
            glBindTexture(GLenum(GL_TEXTURE_2D), (text?._timeTexName)!)

            #if !TARGET_IOS
                // Generate mipmaps from the rendered-to base level
                //   Mipmaps reduce shimmering pixels due to better filtering
                // This call is not accelarated on iOS so do not use mipmaps here
                glGenerateMipmap(GLenum(GL_TEXTURE_2D))
            #endif
        }
        else {
            glActiveTexture(GLenum(GL_TEXTURE0))
            glBindTexture(GLenum(GL_TEXTURE_2D), (text?._timeTexName)!)
        }
        glUseProgram(_textProgram!.prgName);
    }
}
