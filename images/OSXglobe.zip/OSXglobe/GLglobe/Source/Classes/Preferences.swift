//
//  Preferences.swift
//  GLglobe
//
//  Created by Roland Pfeifer on 09/11/21.
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation

fileprivate let defaults: UserDefaults = UserDefaults.standard

public struct Preferences {
    static var latitude: Int {
        get {
            return defaults.integer(forKey: .latitude)!
        }
        
        set {
            defaults.set(newValue, forKey: .latitude)
            defaults.synchronize()
        }
    }
    
    static var longitude: Int {
        get {
            return defaults.integer(forKey: .longitude)!
        }
        
        set {
            defaults.set(newValue, forKey: .longitude)
            defaults.synchronize()
        }
    }
    
    
    static var twilight: Int {
        get {
            return defaults.integer(forKey: .twilight)!
        }
        
        set {
            defaults.set(newValue, forKey: .twilight)
            defaults.synchronize()
        }
    }

    static var textColor: NSColor {
        get {
            var color: NSColor? = defaults.color(forKey: .textColor)
            if (color == nil) {
                color = NSColor.yellow
            }
            return color!
        }

        set {
            let data : NSData = NSKeyedArchiver.archivedData(withRootObject: newValue) as NSData
            defaults.set(data, forKey: .textColor)
            defaults.synchronize()
        }
    }

    static var locationNight: NSColor {
        get {
            var color: NSColor? = defaults.color(forKey: .locationNight)
            if (color == nil) {
                color = NSColor.blue
            }
            return color!
        }

        set {
            let data : NSData = NSKeyedArchiver.archivedData(withRootObject: newValue) as NSData
            defaults.set(data, forKey: .locationNight)
            defaults.synchronize()
        }
    }

    static var locationDay: NSColor {
        get {
            var color: NSColor? = defaults.color(forKey: .locationDay)
            if (color == nil) {
                color = NSColor.red
            }
            return color!
        }

        set {
            let data : NSData = NSKeyedArchiver.archivedData(withRootObject: newValue) as NSData
            defaults.set(data, forKey: .locationDay)
            defaults.synchronize()
        }
    }

    static var textFont: NSFont {
        get {
            var font: NSFont? = defaults.font(forKey: .textFont)
            if (font == nil) {
                font = NSFont.userFont(ofSize: CGFloat(Text.DefaultFontSize))
            }
            return font!
        }

        set {
            let data : NSData = NSKeyedArchiver.archivedData(withRootObject: newValue) as NSData
            defaults.set(data, forKey: .textFont)
            defaults.synchronize()
        }
    }

    static var dateFormat: String {
        get {
            var dateFormat = defaults.string(forKey: .dateFormat)
            if dateFormat == nil {
                dateFormat = "%F %R%nrise %rise set %set δ %dec°"
            }
            return dateFormat!
        }

        set {
            defaults.set(newValue, forKey: .dateFormat)
            defaults.synchronize()
        }

    }

    static func restore() {
        Preferences.latitude = 0
        Preferences.longitude = 0
        Preferences.twilight = 10
    }
}
