 /*
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 OpenGL view subclass.
 */


#import <Cocoa/Cocoa.h>
#import <QuartzCore/CVDisplayLink.h>

//#import "modelUtil.h"
#include "glUtil.h"         // header is need as it ensures we can use gl3

@interface GLglobeGLView : NSOpenGLView {
	CVDisplayLinkRef displayLink;

}
- (void)resetRotation;
+ (NSString*)makeDate: (NSString*) format;
@end
