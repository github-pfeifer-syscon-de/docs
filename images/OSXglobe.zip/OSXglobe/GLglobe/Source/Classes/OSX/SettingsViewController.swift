//
//  SettingsView.swift
//  GLglobe
//
//  Created by Roland Pfeifer on 09/11/21.
//  Copyright © 2021 Roland Pfeifer. All rights reserved.
//

import Foundation
import Cocoa

@objc public protocol SettingsDelegate {
    func resetRotation(sender: SettingsViewController) -> Void

}

public class SettingsViewController : NSViewController, NSWindowDelegate {
    var delegate: SettingsDelegate!
    var window: NSWindow?

    @IBOutlet weak var longitude: NSTextField!
    @IBOutlet weak var latitude: NSTextField!
    @IBOutlet weak var twilight: NSSlider!
    @IBOutlet weak var textColor: NSColorWell!
    @IBOutlet weak var locationNight: NSColorWell!
    @IBOutlet weak var locationDay: NSColorWell!

    @IBOutlet weak var textFormat: NSTokenField!
    @IBOutlet weak var tokenSource: NSTokenField!

    @IBAction func onAction(_ sender: NSSliderCell) {
        Preferences.twilight = Int(sender.intValue)
        if window != nil {
            window!.display()
        }
    }

    @IBAction func longitudeAction(_ sender: NSTextField) {
        delegate.resetRotation(sender: self)
        Preferences.longitude = Int(sender.intValue)
        if window != nil {
            window!.display()
        }
    }

    @IBAction func latitudeAction(_ sender: NSTextField) {
        delegate.resetRotation(sender: self)
        Preferences.latitude = Int(sender.intValue)
        if window != nil {
            window!.display()
        }
    }

    @IBAction func textColor(_ sender: NSColorWell) {
        Preferences.textColor = sender.color
        if window != nil {
            window!.display()
        }
    }

    @IBAction func locationNight(_ sender: NSColorWell) {
        Preferences.locationNight = sender.color
        if window != nil {
            window!.display()
        }
    }

    @IBAction func locationDay(_ sender: NSColorWell) {
        Preferences.locationDay = sender.color
        if window != nil {
            window!.display()
        }
    }


    @IBAction func fontSelect(_ sender: Any) {
        let fontPanel = NSFontPanel.shared()
        fontPanel.setPanelFont(Preferences.textFont, isMultiple: false)
        fontPanel.makeKeyAndOrderFront(self)
        fontPanel.delegate = self
    }

    @IBAction func textFormatChange(_ sender: NSTokenField) {
        Preferences.dateFormat = sender.stringValue
        if window != nil {
            window!.display()
        }
    }

    public override func changeFont(_ sender:Any?) {
        //NSLog("changeFont \(sender)")
        if let mngr = sender as? NSFontManager? {
            if mngr != nil {
                let actualFont = Preferences.textFont
                if let selectedFont: NSFont = mngr?.convert(actualFont) {
                    Preferences.textFont = selectedFont
                    if window != nil {
                        window!.display()
                    }
                    // Preferences.textColor = mngr?.colorget
                    //if window != nil {
                    //    let event = NSEvent.otherEvent(with: NSEventType.applicationDefined,
                    //                                   location: CGPoint(x: 0, y: 0),
                    //                                   modifierFlags: NSEventModifierFlags(),
                    //                                   timestamp: TimeInterval(),
                    //                                   windowNumber: (window?.windowNumber)!,
                    //                                   context: nil,
                    //                                   subtype: 1, data1: 0, data2: 0)
                    //    window!.sendEvent(event!)
                    //    NSLog("Send event \((window?.windowNumber)!)")
                    //}
                    //else {
                    //    NSLog("No windows setted!")
                    //}
                }
                else {
                    NSLog("No font \(mngr) ?")
                }
            }
            else {
                NSLog("No mngr \(mngr) ?")
            }
        }
        else {
            NSLog("Not FontManager but \(type(of: sender))")
        }
    }

    public override func validModesForFontPanel(_ fontPanel:NSFontPanel) -> Int {
        return Int(NSFontPanelFaceModeMask | NSFontPanelSizeModeMask | NSFontPanelCollectionModeMask )  // use font dlg colors? | NSFontPanelTextColorEffectModeMask
    }

    public override func viewDidLoad() {
        super.viewDidLoad()

        longitude.intValue = Int32(Preferences.longitude)
        latitude.intValue = Int32(Preferences.latitude)
        twilight.intValue = Int32(Preferences.twilight)
        textColor.color = Preferences.textColor
        locationNight.color = Preferences.locationNight
        locationDay.color = Preferences.locationDay
        textFormat.stringValue = Preferences.dateFormat

        //textFormat.delegate = DateTokenDelegate()
        //tokenSource.delegate = DateTokenDelegate()

        let newArray = NSMutableArray()
        if let array: NSArray = tokenSource.objectValue as! NSArray? {
            newArray.addObjects(from: array as! [Any])
        }
        //let coder = DateCoder("a")
        let tokenField = DateToken("a")
        newArray.add(tokenField)
        tokenSource.objectValue = newArray
    }
    
    //@IBAction func ok(_ sender: NSButton) {
    //    Preferences.longitude = Int(longitude.intValue)
    //    Preferences.latitude = Int(latitude.intValue)
    //    Preferences.twilight = Int(twilight.intValue)
    //    Preferences.textColor = textColor.color
    //    Preferences.locationNight = locationNight.color
    //    Preferences.locationDay = locationDay.color
    //    delegate.onSubmit(sender: self)
    //}
    
}

public class DateTokenDelegate : NSObject, NSTokenFieldDelegate {
    // Each element in the array should be an NSString or an array of NSStrings.
    // substring is the partial string that is being completed.  tokenIndex is the index of the token being completed.
    // selectedIndex allows you to return by reference an index specifying which of the completions should be selected initially.
    // The default behavior is not to have any completions.
    //public func tokenField(_ tokenField: NSTokenField, completionsForSubstring substring: String, indexOfToken tokenIndex: Int, indexOfSelectedItem selectedIndex: UnsafeMutablePointer<Int>?) -> [Any]? {
    //}


    // return an array of represented objects you want to add.
    // If you want to reject the add, return an empty array.
    // returning nil will cause an error.
    public func tokenField(_ tokenField: NSTokenField, shouldAdd tokens: [Any], at index: Int) -> [Any] {
        var newArray = [Any]()
        newArray.insert(contentsOf: tokens, at: index)
        return newArray
    }


    // If you return nil or don't implement these delegate methods, we will assume
    // editing string = display string = represented object
    public func tokenField(_ tokenField: NSTokenField, displayStringForRepresentedObject representedObject: Any?) -> String? {
        if let cell = representedObject as! DateToken? {
            return cell.name
        }
        return "?"
    }

    //public func tokenField(_ tokenField: NSTokenField, editingStringForRepresentedObject representedObject: Any) -> String? {
    //}

    public func tokenField(_ tokenField: NSTokenField, representedObjectForEditing editingString: String) -> Any {
        return DateToken(editingString)
    }


    // We put the string on the pasteboard before calling this delegate method.
    // By default, we write the NSStringPboardType as well as an array of NSStrings.
    // public func tokenField(_ tokenField: NSTokenField, writeRepresentedObjects objects: [Any], to pboard: NSPasteboard) -> Bool


    // Return an array of represented objects to add to the token field.
    //public func tokenField(_ tokenField: NSTokenField, readFrom pboard: NSPasteboard) -> [Any]? {


    // By default the tokens have no menu.
    //public func tokenField(_ tokenField: NSTokenField, menuForRepresentedObject representedObject: Any) -> NSMenu? {
    //    return nil
    //}

    public func tokenField(_ tokenField: NSTokenField, hasMenuForRepresentedObject representedObject: Any) -> Bool {
        return false
    }


    // This method allows you to change the style for individual tokens as well as have mixed text and tokens.
    public func tokenField(_ tokenField: NSTokenField, styleForRepresentedObject representedObject: Any) -> NSTokenStyle {
        return NSTokenStyle.rounded
    }
}

public class DateToken : NSObject {
    var name: String

    init(_ name: String) {
        self.name = name
    }

    func initWithCoder(decoder: NSCoder) -> Any {
        name = decoder.decodeObject() as! String
        return self;

    }
    func encodeWithCoder(encoder: NSCoder) {
        return encoder.encode(self.name)
    }


}
