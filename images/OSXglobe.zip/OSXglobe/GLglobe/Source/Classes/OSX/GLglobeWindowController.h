/*
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Window controller subclass.
 */


#import <Cocoa/Cocoa.h>
#import "GLglobeGLView.h"

@interface GLglobeWindowController : NSWindowController

@end
