/*
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 OpenGL view subclass.
 */
#include <time.h>
#include <xlocale.h>

#import "GLglobeGLView.h"
//#import "OpenGLRenderer.h"
#import "GLglobe-Swift.h"

#define SUPPORT_RETINA_RESOLUTION 1

@interface GLglobeGLView ()
{
    OpenGLRenderer* _renderer;
    CVTimeStamp _outputTime;
    NSTimer *renderTimer;
    id _eventMonitor;
    NSTrackingArea* _trackingArea;
}
@end

@implementation GLglobeGLView


- (CVReturn) getFrameForTime:(const CVTimeStamp*)outputTime
{
	// There is no autorelease pool when this method is called
	// because it will be called from a background thread.
    // It's important to create one or app can leak objects.
    @autoreleasepool {
        _outputTime = *outputTime;  // keep time
        [self drawView];
    }
	return kCVReturnSuccess;
}

// This is the renderer output callback function
static CVReturn MyDisplayLinkCallback(CVDisplayLinkRef displayLink,
									  const CVTimeStamp* now,
									  const CVTimeStamp* outputTime,
									  CVOptionFlags flagsIn,
									  CVOptionFlags* flagsOut, 
									  void* displayLinkContext)
{
    CVReturn result = [(__bridge GLglobeGLView*)displayLinkContext getFrameForTime:outputTime];
    return result;
}

- (void) awakeFromNib
{
    NSOpenGLPixelFormatAttribute attrs[] =
	{
		NSOpenGLPFADoubleBuffer,
		NSOpenGLPFADepthSize, 24,
		// Must specify the 3.2 Core Profile to use OpenGL 3.2
#if ESSENTIAL_GL_PRACTICES_SUPPORT_GL3 
		NSOpenGLPFAOpenGLProfile,
		NSOpenGLProfileVersion3_2Core,
#endif
		0
	};
	
	NSOpenGLPixelFormat *pf = [[NSOpenGLPixelFormat alloc] initWithAttributes:attrs];
	
	if (!pf)
	{
		NSLog(@"No OpenGL pixel format");
	}
	   
    NSOpenGLContext* context = [[NSOpenGLContext alloc] initWithFormat:pf shareContext:nil];
    
#if ESSENTIAL_GL_PRACTICES_SUPPORT_GL3 && defined(DEBUG)
	// When we're using a CoreProfile context, crash if we call a legacy OpenGL function
	// This will make it much more obvious where and when such a function call is made so
	// that we can remove such calls.
	// Without this we'd simply get GL_INVALID_OPERATION error for calling legacy functions
	// but it would be more difficult to see where that function was called.
	CGLEnable([context CGLContextObj], kCGLCECrashOnRemovedFunctions);
#endif
    
    [self setPixelFormat:pf];
    
    [self setOpenGLContext:context];
    
#if SUPPORT_RETINA_RESOLUTION
    // Opt-In to Retina resolution
    [self setWantsBestResolutionOpenGLSurface:YES];
#endif // SUPPORT_RETINA_RESOLUTION
}

- (void) prepareOpenGL
{
	[super prepareOpenGL];
	// Make all the OpenGL calls to setup rendering
	//  and build the necessary rendering objects
	[self initGL];
	
	// Create a display link capable of being used with all active displays
	CVDisplayLinkCreateWithActiveCGDisplays(&displayLink);
	
	// Set the renderer output callback function
	CVDisplayLinkSetOutputCallback(displayLink, &MyDisplayLinkCallback, (__bridge void*)self);
    
	// Set the display link for the current renderer
	CGLContextObj cglContext = [[self openGLContext] CGLContextObj];
	CGLPixelFormatObj cglPixelFormat = [[self pixelFormat] CGLPixelFormatObj];
	CVDisplayLinkSetCurrentCGDisplayFromOpenGLContext(displayLink, cglContext, cglPixelFormat);
 	
	// Activate the display link
    //CVDisplayLinkStart(displayLink);      // cant determine how to this at a limited rate
    self->renderTimer = [NSTimer scheduledTimerWithTimeInterval: 60.00
                                                         target: self
                                                       selector: @selector(onTick:)
                                                       userInfo: nil
                                                        repeats: YES];
    
    
    NSRunLoop *runner = [NSRunLoop currentRunLoop];
    [runner addTimer:renderTimer forMode: NSDefaultRunLoopMode];
    [runner addTimer:renderTimer forMode: NSEventTrackingRunLoopMode];

	
	// Register to be notified when the window closes so we can stop the displaylink
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(windowWillClose:)
												 name:NSWindowWillCloseNotification
											   object:[self window]];
}

- (void) windowWillClose:(NSNotification*)notification
{
    if (_eventMonitor) {
        [NSEvent removeMonitor:_eventMonitor];
        _eventMonitor = nil;
    }

    //[[NSNotificationCenter defaultCenter] removeObserver:self name:NSWindowWillCloseNotification object:_window];
    //[[NSNotificationCenter defaultCenter] removeObserver:self name:NSApplicationDidResignActiveNotification object:nil];

    // No more timer notifications
    [renderTimer invalidate];
	// Stop the display link when the window is closing because default
	// OpenGL render buffers will be destroyed.  If display link continues to
	// fire without renderbuffers, OpenGL draw calls will set errors.
	CVDisplayLinkStop(displayLink);
}

- (void) mouseEntered:(NSEvent*)theEvent
{
    // Mouse entered tracking area.
    [_renderer setInside: 1];
    [self drawView];
    //NSLog([NSString stringWithFormat:@"MouseEntered value is "]);
}

- (void) mouseExited:(NSEvent*)theEvent
{
    // Mouse exited tracking area.
    [_renderer setInside: 0];
    [self drawView];
    //NSLog([NSString stringWithFormat:@"MouseExited value is "]);
}

- (void)mouseMoved:(NSEvent *)event
{
    // use for tooltip
    NSPoint winPoint = [event locationInWindow];
    //NSPoint curPoint = [self convertPoint:[event locationInWindow] toView:nil];
    //NSLog([NSString stringWithFormat:@"mouseMoved value win x %f y %f cur x %f y %f", winPoint.x, winPoint.y, curPoint.x, curPoint.y]);
    [_renderer setMouseWithPos: winPoint];
    [self drawView];
}

- (void)scrollWheel:(NSEvent *)event
{
    //NSLog([NSString stringWithFormat:@"ScrollEvent value is dx %f dy %f", [incomingEvent scrollingDeltaX], [incomingEvent scrollingDeltaY]]);
    float zoffs = [event scrollingDeltaY];
    [_renderer addWithZoffset: zoffs * 2.0];
    [self drawView];
}

- (void)mouseDragged:(NSEvent *)event
{
    //NSLog([NSString stringWithFormat:@"DragEvent value is dx %f dy %f", [incomingEvent deltaX], [incomingEvent deltaY]]);
    [_renderer addWithHoffset: -[event deltaX]];
    [self drawView];
}

- (void)resetRotation
{
    [_renderer resetRotation];

}

- (void)animateDock
{
    NSDockTile *dockTile=[[NSApplication sharedApplication] dockTile];
    NSImageView *dockImageView=[[NSImageView alloc] init];
    NSSize size = [dockTile size];
    //NSImage *iconImage=[NSImage imageNamed: ##MY_IMAGE_FRAME##];
    //[dockImageView setImage: iconImage];
    //[dockTile setContentView: dockImageView];
    //[dockTile display];
}

- (void)listenToMouse
{
    // Start watching events to
    //NSAssert(_eventMonitor == nil, @"_eventMonitor should not be created yet");
    //NSTrackingAreaOptions options = (NSMouseEnteredAndExited);
    if (_trackingArea) {
        [self removeTrackingArea: _trackingArea];
    }
    _trackingArea = [[NSTrackingArea alloc] initWithRect: self.bounds options: (NSTrackingMouseEnteredAndExited | NSTrackingMouseMoved | NSTrackingActiveAlways) owner: self userInfo: nil];
    [self addTrackingArea: _trackingArea];
}



- (void) listenToInternalMessage
{
    //_eventMonitor = [NSEvent addLocalMonitorForEventsMatchingMask:
    //                 (NSEventMaskApplicationDefined)
    //                                                      handler:^(NSEvent *incomingEvent) {
    //                                                          NSEventType eventType = [incomingEvent type];
    //                                                          NSLog([NSString stringWithFormat:@"AppEvent value is %d", (int)incomingEvent.subtype]);
    //                                                          NSEvent* result = nil;
    //                                                          return result;
    //                                                      }
    //                 ];
}

- (void) initGL
{
    [self listenToMouse];
    //[self listenToInternalMessage];
	// The reshape function may have changed the thread to which our OpenGL
	// context is attached before prepareOpenGL and initGL are called.  So call
	// makeCurrentContext to ensure that our OpenGL context current to this 
	// thread (i.e. makeCurrentContext directs all OpenGL calls on this thread
	// to [self openGLContext])
	[[self openGLContext] makeCurrentContext];
	
	// Synchronize buffer swaps with vertical refresh rate
	GLint swapInt = 1;
	[[self openGLContext] setValues:&swapInt forParameter:NSOpenGLCPSwapInterval];
	
    // ensure some values
    _outputTime.videoTime = 0;
    _outputTime.videoTimeScale = 1;
    // Init our renderer.  Use 0 for the defaultFBO which is appropriate for
	// OSX (but not iOS since iOS apps must create their own FBO)
	_renderer = [[OpenGLRenderer alloc] initWithDefaultFBO:0];
}

- (void)reshape
{	
	[super reshape];
	
	// We draw on a secondary thread through the display link. However, when
	// resizing the view, -drawRect is called on the main thread.
	// Add a mutex around to avoid the threads accessing the context
	// simultaneously when resizing.
	CGLLockContext([[self openGLContext] CGLContextObj]);

	// Get the view size in Points
	NSRect viewRectPoints = [self bounds];
    
#if SUPPORT_RETINA_RESOLUTION

    // Rendering at retina resolutions will reduce aliasing, but at the potential
    // cost of framerate and battery life due to the GPU needing to render more
    // pixels.

    // Any calculations the renderer does which use pixel dimentions, must be
    // in "retina" space.  [NSView convertRectToBacking] converts point sizes
    // to pixel sizes.  Thus the renderer gets the size in pixels, not points,
    // so that it can set it's viewport and perform and other pixel based
    // calculations appropriately.
    // viewRectPixels will be larger than viewRectPoints for retina displays.
    // viewRectPixels will be the same as viewRectPoints for non-retina displays
    NSRect viewRectPixels = [self convertRectToBacking:viewRectPoints];
    
#else //if !SUPPORT_RETINA_RESOLUTION
    
    // App will typically render faster and use less power rendering at
    // non-retina resolutions since the GPU needs to render less pixels.
    // There is the cost of more aliasing, but it will be no-worse than
    // on a Mac without a retina display.
    
    // Points:Pixels is always 1:1 when not supporting retina resolutions
    NSRect viewRectPixels = viewRectPoints;
    
#endif // !SUPPORT_RETINA_RESOLUTION
    [self listenToMouse];
	// Set the new dimensions in our renderer
	[_renderer resizeWithWidth:viewRectPixels.size.width
                      AndHeight:viewRectPixels.size.height];
	
	CGLUnlockContext([[self openGLContext] CGLContextObj]);
}


- (void)renewGState
{	
	// Called whenever graphics state updated (such as window resize)
	
	// OpenGL rendering is not synchronous with other rendering on the OSX.
	// Therefore, call disableScreenUpdatesUntilFlush so the window server
	// doesn't render non-OpenGL content in the window asynchronously from
	// OpenGL content, which could cause flickering.  (non-OpenGL content
	// includes the title bar and drawing done by the app with other APIs)
	[[self window] disableScreenUpdatesUntilFlush];

	[super renewGState];
}

- (void) drawRect: (NSRect) theRect
{
	// Called during resize operations
	
	// Avoid flickering during resize by drawiing	
	[self drawView];
}

-(void)onTick:(NSTimer*)timer
{
    [self drawView];
}

- (void) drawView
{	 
	[[self openGLContext] makeCurrentContext];

	// We draw on a secondary thread through the display link
	// When resizing the view, -reshape is called automatically on the main
	// thread. Add a mutex around to avoid the threads accessing the context
	// simultaneously when resizing
	CGLLockContext([[self openGLContext] CGLContextObj]);

    [_renderer render:(&_outputTime)];

	CGLFlushDrawable([[self openGLContext] CGLContextObj]);
	CGLUnlockContext([[self openGLContext] CGLContextObj]);
}

//- (void)noResponderFor:(SEL)eventSelector
//{
    //if (eventSelector->type == NSEventTypeApplicationDefined) {
//    NSLog(@"noResponderFor %s %ld", eventSelector, [[self window] windowNumber]);
    //}
    //else {
//    [super noResponderFor: eventSelector];
    //}
//}

// convenicence bridge to unix strftime
+ (NSString*)makeDate: (NSString*)format
{
    time_t timet;
    struct tm* ltm;
    //locale_t locale;
    const char* cfmt;
    char dates[256];
    setlocale(LC_ALL, "");

    // using the posix function is a convenience solution (as c doesnt know about unicode, this works for simple cases ...)
    //  a fully working version woud convert unicodes to /uNNNN; and back on return
    //  alternative port to swift or implement something like the macOS system format dialog...
    timet = time(NULL);
    ltm = localtime(&timet);
    cfmt = (char*)[format UTF8String];
    strftime(dates, sizeof(dates), cfmt, ltm);
    NSString* date = [NSString stringWithUTF8String: dates];
    return date;
}

- (void) dealloc
{
    [renderTimer invalidate];
	// Stop the display link BEFORE releasing anything in the view
    // otherwise the display link thread may call into the view and crash
    // when it encounters something that has been release
	CVDisplayLinkStop(displayLink);

	CVDisplayLinkRelease(displayLink);
}
@end
