//
//  AppDelegate.swift
//  GLEssentials
//
//  Created by Roland Pfeifer on 01/11/21.
//

import Foundation
import Cocoa


let settingsWindowController: NSWindowController = NSWindowController(window: nil)


@NSApplicationMain
class AppDelegate : NSObject, NSApplicationDelegate, SettingsDelegate {
    weak var window: NSWindow?

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        window = NSApplication.shared().windows[0]
        //NSLog("AppDelegate init \((window?.windowNumber)!)")
    }
    
    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }
    
    @IBAction func showSettings(_ sender: Any) {
        let storyboard = NSStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateController(withIdentifier: "SettingsViewController") as! SettingsViewController
        vc.delegate = self
        let window: NSWindow = {
            let w = NSWindow(contentViewController: vc)
            
            w.styleMask.remove(.fullScreen)
            w.styleMask.remove(.resizable)
            w.styleMask.remove(.miniaturizable)

            w.title = "Preferences"
            //w.level = .floating
            
            return w
        }()
        
        if settingsWindowController.window == nil {
            settingsWindowController.window = window
        }
        vc.window = self.window
        
        settingsWindowController.showWindow(self)
        //}
        //else {
        //    NSLog("Coud not get SettingsViewController")
        //}
        
    }

    func resetRotation(sender: SettingsViewController) -> Void {
        if (window != nil) {
            let view = window!.contentView  as! (GLglobeGLView)
            view.display()
            view.resetRotation()
        }
        else {
            NSLog("No window to refresh.")
        }
    }

}
