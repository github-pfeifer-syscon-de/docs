-- 
-- made this work with:
-- for local map
-- /way 52.4 35.3
-- /way Antoran Wastes 52.4 35.3 Fiend Bone
-- locate zone 
-- /way Antoran Wastes
-- Use with continent 
-- /way Shadowmoon Valley:Draenor 56 41.1 

-- mapID to show hierarchy for 
-- show boolean to show info or not
-- prefix text to prefix
-- return the "cosmic" mapID
function mapInfo(mapID, show, prefix)
	local mapingId = mapID
	local msg = ""
  	for i = 1, 10, 1 do
		local info = C_Map.GetMapInfo(mapingId)
		local location = "" 
		if (info.mapType == 1) then 
			location  = "Cosmic"
		end	
		if (info.mapType == 2) then 
			location = "Continent"
		end
		if (info.mapType == 3) then 
			location = "Zone"
		end
		if (info.mapType == 4) then 
			location = "Dungeon"
		end
		if (info.mapType == 5) then 
			location = "Micro"
		end
		if (info.mapType > 1) then	-- dont need cosmic in output
			if (string.len(msg) > 0) then
				msg = msg.." > "
			end
			msg = msg..location.." "..info.name
		else 
		   break			
		end
		mapingId = info.parentMapID
  	end
	if (show) then
		msg = prefix..msg
		DEFAULT_CHAT_FRAME:AddMessage(msg)
	end	
  	return mapingId
end;  	

-- globalMapID the hierarchy to search (do find all its best to use univers)
-- zone to find mapID for
-- mapType e.g. 2 = world/contitent, 3 = zone, 4 dungeon
-- return the mapID that match zone and mapType
function mapFindName(globalMapID, zone, mapType)  	
    -- map entry structure
  	--{ mapType=3,
 	-- mapID=885,
  	-- name="Antoran Wastes",
  	-- parentMapID=905,
  	-- flags=6 }
  	local mapID = globalMapID
	zone = string.lower(zone)
  	local pos = string.find(zone,":")
  	if (pos ~= nil) then
  		local world = string.sub(zone, pos+1, string.len(zone))
  		zone = string.sub(zone, 1, pos-1)
		local found = false
		local list = C_Map.GetMapChildrenInfo(mapID, 2, true)
		for i = 1, #list, 1 do
			if (string.lower(list[i].name) == world) then
				mapID =  list[i].mapID
				found = true
				break;
			end
		end
		if (found == false) then
			showErr(string.format("Coud not identify %s as continent (result may be wrong)!", world))
		end 
  	end
  	local list = C_Map.GetMapChildrenInfo(mapID, mapType, true)
  	for i = 1, #list, 1 do
		if (string.lower(list[i].name) == zone) then
			return list[i].mapID 
		end
  	end
  	return nil
end;

function showDelta(playerMapID, coord) 
	-- as we are on the right map indicate delta
	local pos = C_Map.GetPlayerMapPosition(playerMapID, "player")
	local dX = coord[1] - pos.x * 100;
	local dY = coord[2] - pos.y * 100;
	local dirX,dirY
	if (dX < 0) then
		dirX = "left"
	else 
		dirX = "right"
	end
	if (dY < 0) then
		dirY = "up"
	else
		dirY = "down"
	end
	local msg = string.format("You are getting close %s %.1f %s %.1f", dirX, math.abs(dX), dirY, math.abs(dY))
	DEFAULT_CHAT_FRAME:AddMessage(msg)
end;

-- parse the input 
-- return zone, coords, comment
function parse(args)
	local coord = {}
	local zone = ""
	local comment = ""
	local onZone =  true
	for token in string.gmatch(args, "%S+") do
	    local last = string.sub(token,-1)
	    if last == ',' then		-- coords may be suffixed by ,
	    	local numTest = string.sub(token,1,string.len(token)-1)
	    	local num = tonumber(numTest)
	    	if (type(num) == 'number') then
	    	  token = numTest
	    	end
	    end
		local number = tonumber(token)
		if (type(number) == 'number') then
			coord[#coord + 1] = number
			onZone =  false
		else
			if onZone then
				if (string.len(zone) > 0) then
					zone = zone.." "
				end 
				zone = zone..token
			else
				comment = comment.." "..token
			end
		end
	end
	return zone, coord, comment
end;

function showErr(msg)
	local colErrR, colErrG, colErrB
	colErrR = 1.0
	colErrG = 0.0
	colErrB = 0.0
	DEFAULT_CHAT_FRAME:AddMessage(msg, colErrR, colErrG, colErrB)
end;

function WaypointsNative(args, editbox)
	local zone, coord, comment = parse(args)
  
	local playerMapID = C_Map.GetBestMapForUnit("player")
	local pinMapID
	if (zone ~= "") then 
		if string.sub(zone,1,1) == "#" then		-- e.g. use #8022 to directly address map
		   local mapNum = string.sub(zone, 2, string.len(zone))
		   local mapNo = tonumber(mapNum)
		   pinMapID = mapNo
		else	
			local cosmicMapID = mapInfo(playerMapID, false, "")
			pinMapID = mapFindName(cosmicMapID, zone, 3)	--search for zone
			if (pinMapID == nil) then
				pinMapID = mapFindName(cosmicMapID, zone, 4)	--search for dungeon
				if (pinMapID == nil) then
					showErr(string.format("Sorry coudn't identify %s as zone or dungeon", zone))				
					return
				end
			end
			if (pinMapID ~= playerMapID) then
				mapInfo(pinMapID, true, "You need to travel to ")
			end
		end
	else
		pinMapID = playerMapID
	end
	
	if (#coord == 2) then
		local msg = string.format("Way %s %.1f %.1f %s", zone, coord[1], coord[2], comment)
		DEFAULT_CHAT_FRAME:AddMessage(msg)
		if C_Map.CanSetUserWaypointOnMap(pinMapID) then
			local mapPoint = UiMapPoint.CreateFromCoordinates(pinMapID, coord[1] / 100, coord[2] / 100, 0)
			C_Map.SetUserWaypoint(mapPoint)
			C_SuperTrack.SetSuperTrackedUserWaypoint(true)
		else
			showErr("Cannot set waypoints on this map")
		end
		if (pinMapID == playerMapID) then
			showDelta(playerMapID, coord)
		end	
	else 
		if (zone == "") then	-- it coud be a zone only info
				local pos = C_Map.GetPlayerMapPosition(playerMapID, "player")
				local msg = string.format("Cannot parse x y from '%s' got %d coords\n", args, #coord)..[[
use with "/way x y" for local map
or "/way Antoran Wastes 52.4 35.3 Fiend Bone" for  set pin for remote map
or "/way Shadowmoon Valley:Draenor 56 41.1" to make it disambigious
or "/way Antoran Wastes" to find zone or dungeon
]]..string.format("currently #%d at %.1f %.1f", playerMapID, pos.x*100.0, pos.y*100.0);
		DEFAULT_CHAT_FRAME:AddMessage(msg)
		end
	end
end;

SLASH_WAYPOINTSNATIVE1 = "/way"
SlashCmdList["WAYPOINTSNATIVE"] = WaypointsNative
